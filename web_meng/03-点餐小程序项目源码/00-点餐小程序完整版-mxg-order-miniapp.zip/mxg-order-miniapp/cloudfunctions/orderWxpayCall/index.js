// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV }) // 使用当前云环境

// 云函数入口函数: 订单微信支付完成后，微信支付平台会异步将支付结果调用此云函数进行传递支付结果

// errcode返回0 表示支付通知后已处理成功，不需要再次调用此云函数进行通知
const FAIL = {errcode: -1, errmsg: 'FAIL'}
const SUCCESS = {errcode: 0, errmsg: 'SUCCESS'}

const db = cloud.database()

exports.main = async (event, context) => {
    // 业务订单号，支付结果编码，微信支付订单号，支付完成时间
    const { outTradeNo, resultCode, transactionId, timeEnd } = event

    // 支付失败
    if( resultCode !== 'SUCCESS' ) {
        return FAIL
    }

    // 1. 通过业务订单id查询商品
    const { data } = await db.collection('mxg_order')
        .where({
            orderNo: outTradeNo
        })
        .get()
    if (!data || data.length <= 0) {
        // 无订单，直接返回成功
        return SUCCESS
    }

    const { _id: orderId } = data[0]
    // 2. 更新订单状态：2-已支付
    const updated = await db.collection("mxg_order").doc(orderId)
        .update({
            data: {
                payType: 'wxpay', //支付类型
                state: 2, // 2支付成功
                payOrderId: transactionId, // 微信支付平台的订单id
                payEndTime: timeEnd
            }
        })

    // 3. 更新商品剩余库存
    const { result } = await cloud.callFunction({
        name: 'updateGoodsStock',
        data: {
            orderId: orderId
        }
    })  
    // 更新库存成功，返回SUCCESS
    if (result.success) return SUCCESS  
    // 更新失败，让微信平台再次调用此云函数
    return FAIL
}