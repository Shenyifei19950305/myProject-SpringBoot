// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV }) // 使用当前云环境

const db = cloud.database()
const _ = db.command

// 云函数入口函数: 订单的余额支付
exports.main = async (event, context) => {
    const { memberId, orderId, totalAmount } = event

    // 1. 扣减会员余额
    const updated = await db.collection('mxg_member')
        .where({
            _id: memberId,
            // 保证会员余额充足
            balance: _.gte(totalAmount)
        })
        .update({
            data: { 
                // balance + (-totalAmount)
                // 1 - 0.07 == 0.9299999, 解决：将数据库存balance和totalAmount的元转分
                balance: _.inc(-totalAmount)
            }
        })

    if (!updated.stats.updated) {
        return {success: false, error: '余额扣减失败，请核实余额是否充足'}
    }
    // 2. 扣减商品库存
    const {result} = await cloud.callFunction({
        name: 'updateGoodsStock',
        data: {
            orderId: orderId
        }
    })
    
    if (!result.success) {
        return result
    }

    // 3. 更新订单状态：2-已支付
    await db.collection('mxg_order')
        .doc(orderId)
        .update({
            data: {
                payType: 'balance', // 余额支付
                state: 2, // 1-待支付，2-已支付
                payEndTime: Date.now()
            }
        })

    return {success: true, message: '余额支付成功'}
}