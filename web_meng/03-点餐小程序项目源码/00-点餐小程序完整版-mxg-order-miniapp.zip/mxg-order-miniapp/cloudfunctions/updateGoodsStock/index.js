// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV }) // 使用当前云环境

const db = cloud.database()
const _ = db.command

// 云函数入口函数
exports.main = async (event, context) => {
    const {orderId} = event
    try {
        // 1. 查询订单信息
        const { data: order } = await db.collection('mxg_order').doc(orderId).get()
        if (!order) {
            // 没有订单数据, 直接返回成功
            return { success: true, message: '未查询到订单'+orderId }
        }
        // 获取订单商品
        const { cartList } = order
        if (!cartList || cartList.length <= 0) {
            // 无订单商品，直接返回成功
            return { success: true, message: '未查询到订单商品'+orderId }
        }

        // 2. 循环购物车商品数据，分别提取更新的商品和规格 
        const goodsList = [] // 待更新的商品库存
        const specsList = [] // 待更新的规格库存
        cartList.forEach(item => {
            const { _id: goodsId, specsId, buyNum } = item
            // specsId 有值：多规格商品，更新规格库存
            if (specsId) specsList.push( { goodsId, specsId, buyNum } )
            // specsId 没有值：单规格商品，直接更新商品库存
            else goodsList.push({goodsId, buyNum})
        })

        console.log('更新库存', goodsList, specsList)
        // 更新事务控制 
        const reuslt = await db.runTransaction( async transaction => {
            // 批量更新商品库存数量
            for (const item of goodsList) {
                await transaction.collection('mxg_goods')
                    .doc(item.goodsId)
                    .update({
                        data: {
                            stockNum: _.inc( -item.buyNum )
                        }
                    })
            }

            // 针对多规格商品：更新商品的规格库存数量
            for (const item of specsList) {
                await transaction.collection('mxg_goods')
                    .where({
                        _id: item.goodsId,
                        // 指定的是mxg_goods集合中goodsSpecs数组字段中的id字段值
                        'goodsSpecs._id': item.specsId
                    })
                    .update({
                        data: {
                            // goodsSpecs是对象数组，后面需要跟上$，再进行定位到具体的哪个字段名。加了$就会更新第一个满足条件的字段中
                            'goodsSpecs.$.stockNum': _.inc( -item.buyNum )
                        }
                    })
            }
            // 会作为runTransaction resolve 的结果返回（成功结果）
            return { message: '扣减商品库存功能' }
        })

        // 返回给调用此云函数的调用方
        return {success: true, message: reuslt.message}
    } catch (error) {
        console.error('更新商品库存失败', error)
        return {success: false, error: '更新商品库存失败'}
    }
    
}