// pages/login/login.js

import { hideLoading, msg, navBack, showLoading } from "@/utils/util"

Page({

  /**
   * 页面的初始数据
   */
  data: {
    agree: false, //是否同意协议
    member: null, // 会员信息
    boundMobile: false, // 是否绑定手机号，true绑定了快速登录，false未绑定获取用户手机登录
  },

  onLoad() {
      this.preLogin()
  },

  /**
   * 预登录：
   */
  async preLogin() {
      try {
        showLoading()
        // 调用预登录云函数
        const { result: member } = await wx.cloud.callFunction({
            name: 'preLogin'
        })  
        // console.log('result', member)

        // 判断是否绑定了手机号，
        const boundMobile = !!(member && member.mobile)
        // console.log('boundMobile', boundMobile)

        this.setData({
            member,
            boundMobile
        })
      } catch (error) {
          console.error('预登录异常', error)
      } finally {
        hideLoading()
      }
  },

  loginCheck() {
    if (!this.data.agree) {
        return msg('请阅读并勾选下方协议')
    }
  },

  /**
   * 快速登录
   */
  loginQuick() {
    // console.log('loginQuick')
    try {
        showLoading()
        const { boundMobile } = this.data
        // 如果未绑定，则结束
        if (!boundMobile) return
        // 已绑定：保存会员信息到本地storage中，表示登录成功
        this.loginSuccess()
    } catch (error) {
        msg('登录失败')
        console.error('快速登录异常', error)
    } finally {
        hideLoading()
    }
  },

  /**
   * 登录成功，保存会员信息到本地
   */
  loginSuccess() {
    // 保存会员信息到本地
    getApp().storageMember(this.data.member)
    msg('登录成功', {icon: 'success'})
    navBack() // 后退
  },
  
  async loginGetPhoneNumber(e) {
    console.log('loginGetPhoneNumber', e)
    try {
        showLoading('登录中')
        // 接收用户同意授权获取手机号的授权码code，通过code交换手机号
        const {code} = e.detail
        if (!code) return

        // 调用云函数：通过授权码code换取手机号
        const {result: member} = await wx.cloud.callFunction({
            name: 'getPhoneNumber',
            data: {
                code //code: code //  授权码
            }
        })
        // console.log('result', member)

        // 更新状态数据
        this.setData({
            member,
            boundMobile: true
        })
        // 登录成功
        this.loginSuccess()
    } catch (error) {
        msg('登录失败') 
        console.error('loginGetPhoneNumber授权手机号登录失败 ', error)  
    } finally {
        hideLoading()
    }
  },
  
})