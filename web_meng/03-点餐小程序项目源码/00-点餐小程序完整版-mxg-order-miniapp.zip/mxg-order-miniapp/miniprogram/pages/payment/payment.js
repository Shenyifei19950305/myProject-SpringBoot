// pages/payment/payment.js
import { showLoading, hideLoading, msg, navBack, navTo, redirectTo } from '@/utils/util'
import { getMemberById } from '@/api/member'
import { wxpay } from '@/api/pay'

Page({

  data: {
    orderId: '',
    order: null, 
    showBalancePay: false, // 是否显示余额支付：已登录且有足够余额时显示
    member: null, // 登录会员信息
    payType: 'wxpay', // wxpay微信支付，balance余额支付 
  },

  onLoad(options) {
    const {orderId} = options
    if (!orderId) return
    this.setData({orderId})

    // 查询订单信息
    this.loadOrder()
    // 查询会员信息
    this.loadMember()
  },

  // 查询订单信息
  async loadOrder() {
      try {
        showLoading()
        const {orderId} = this.data
        // 查询当前订单id为未支付的订单信息
        const { data } = await wx.cloud.database().collection('mxg_order')
                .doc(orderId).get()
        if (!data || !data._id) {
            return msg("订单不存在")
        }
        // 判断状态state=1未支付状态，才可以发起支付
        if (data.state != 1) {
            // redirectTo('/pages/order-detail/order-detail?orderId=' + orderId)
            this.toOrderDetailPage()
            return msg("当前订单不是[未支付]状态，不允许进行支付")
        }
        this.setData({order: data})
        this.isShowBalancePay()
        // console.log('data', data)
      } catch (error) {
          console.error("查询订单信息失败", error)
          msg('查询订单失败', {icon: 'error'})
      } finally {
         hideLoading()
      }
  },

  // 查询登录的会员信息
  async loadMember() {
    try {
        showLoading()
        // 1. 获取当前登录会员信息
        const {logined, member} = getApp().current()
        
        if (!logined) {
            // 未登录过，隐藏余额支付
            this.setData({showBalancePay: false})
            return
        }
        // 2. 查询会员信息
        const { data } = await getMemberById(member._id)
        this.setData({member: data})
        this.isShowBalancePay()
        // console.log('loadMember', data)
    } catch (error) {
        console.error('查询会员失败', error)
    } finally {
        hideLoading()
    }
  },

  // 是否显示余额支付
  isShowBalancePay() {
    const {member, order} = this.data 
    if (!member || !order || !order._id) return 

    // 判断余额是否充足，充足则显示余额支付
    const showBalancePay = member.balance >= order.totalAmount
    // 显示余额支付时，默认选择：余额支付
    const payType = showBalancePay ? 'balance': 'wxpay'
    this.setData({showBalancePay, payType})
  },

  // 确认支付
  confirmPay() {
    const {payType, order} = this.data 
    if (!order || !order._id ) {
        return msg('未查询到订单信息')
    }

    // 判断支付方式
    if (payType == 'wxpay') {
        this.handleWxpay()
    } else if(payType == 'balance') {
        this.handleBalancePay()
    } else {
        msg('请选择支付方式')
    }

  },

  // 微信支付处理
  async handleWxpay() {
    // console.log('handleWxpay')
    try {
        showLoading('发起支付中', {mask: true})

        const {_id, shopName, totalAmount} = this.data.order

        // 业务订单号，每次发起支付请求，要保证唯一的，不能重复
        const orderNo = _id.substring(0, 8) + Date.now()
        // 更新业务订单号
        await wx.cloud.database().collection('mxg_order')
            .doc(_id)
            .update({
                data: {
                    orderNo: orderNo
                }
            })

        // 发起支付
        const payRes = await wxpay(shopName || '结账支付', orderNo, totalAmount, 'orderWxpayCall')
        // console.log("支付成功", payRes)
        
        msg('支付成功', {icon: 'success'})
        this.toOrderDetailPage()
    } catch (error) {
        console.error('微信支付失败', error)
        msg('支付失败', {icon: 'error'})
        this.toOrderDetailPage()
    } finally {
        setTimeout(() => {
            hideLoading()
        }, 500);
    }
  },

  // 余额支付处理
  async handleBalancePay() {
    console.log('handleBalancePay')
    try {
        showLoading('支付中', {mask: true})

        const {member, order} = this.data

        // 调用云函数进行余额支付
        const { result } = await wx.cloud.callFunction({
            name: 'orderBalancePay',
            data: {
                memberId: member._id,
                orderId: order._id,
                totalAmount: order.totalAmount
            }
        })
        console.log('余额支付结果', result)
        if (!result.success) {
            return msg(result.error)
        }
        msg('支付成功', {icon: 'success'})
        // 支付成功：跳转订单详情页
        this.toOrderDetailPage()
    } catch (error) {
        console.error('余额支付失败', error)
        this.toOrderDetailPage()
    } finally {
        setTimeout(() => {
            hideLoading()
        }, 500)
    }
  },

  // 跳转到订单详情页
  toOrderDetailPage() {
    redirectTo('/pages/order-detail/order-detail?orderId=' + this.data.orderId)
  }
  

})