// pages/address-list/address-list.js
import { hideLoading, msg, navBack, showLoading, navTo } from "@/utils/util"

Page({

    data: {
        checkedId: '', // 选中的地址id
        addressList: [
            /* {
                _id: 1, 
                locationName: '腾王阁', 
                streetNumber: '1101室201',
                name: '张三', 
                mobile: '18889999123'
            },
            {
                _id: 2, 
                locationName: '腾王阁', 
                streetNumber: '1101室201',
                name: '张三', 
                mobile: '18889999123'
            } */
        ],
        isOpen: false, // 是否展开显示删除按钮
    },

    navTo, // 页面跳转

    onLoad(options) {
        this.setData({checkedId: options.addressId || ''})
    },
    
    onShow() {
        // 触发下拉刷新
        wx.startPullDownRefresh()
    },

    // 当下拉刷新后会进行触发
    onPullDownRefresh() {
        this.loadList()
    },

    async loadList() {
       try {
           // 清空原选中的地址id
            this.setData({ checkedId: '' })

            const { data: addressList } = await wx.cloud.database()
                .collection('mxg_address').get()

            this.setData({ addressList })
            // console.log('addressList', addressList)
       } catch (error) {
           console.error('查询地址信息失败', error)
           msg('查询数据失败', {icon: 'error'})
       } finally {
           // 停止下拉刷新动画
           wx.stopPullDownRefresh()
       }
    },

    async handleDelete(e) {
        // console.log('e', e)
        const {item} = e.currentTarget.dataset
        const res = await wx.showModal({
            title: '您是否确认删除地址？',
            cancelText: '取消',
            confirmText: '确认',
            cancelColor: '#333',
            confirmColor: '#e40030'
        })
        console.log('res', res)
        // 点击取消，直接结束不进行删除
        if (res.cancel) return 

        try {
            showLoading('删除中', {mask: true})
             // 执行删除操作
            const deleted = await wx.cloud.database().collection('mxg_address')
                .doc(item._id).remove()
            msg('删除成功')
            wx.startPullDownRefresh() // 触发下拉刷新调用onPullDownRefresh事件函数查询列表数据
            //this.setData({isOpen: false}) 
        } catch (error) {
            console.error('删除失败', error)
            msg('删除失败', {icon: 'error'})
        } finally {
            hideLoading()
        }
       
    },

    handleAddress(e) {
        console.log('handleAddress', e)
        if (this.data.isOpen) return
        const {item} = e.currentTarget.dataset
        this.setData({checkedId: item._id})
    },

    // 前往点单页面(后退)
    toShoppingPage() {
       const {checkedId, addressList} = this.data

       // 获取选中的地址对象
       const selectedAddress = addressList?.find(item => item._id === checkedId)
       console.log('selectedAddress', selectedAddress)

       if (!selectedAddress) {
           msg('请选择地址', {icon: 'error'})
           return
       }

       // 触发来源页面的事件，将选中的地址传递回去
       const eventChannel = this.getOpenerEventChannel()
       console.log('eventChannel', eventChannel)
       if(Object.keys(eventChannel).length>0) {
            eventChannel?.emit('updateAddress', selectedAddress)
       }
       navBack() // 后退
    },

    // 打开滑块
    openSwipe(e) {
        console.log('openSwipe', e)
        this.setData({isOpen: true})
    },

    // 关闭滑块
    closeSwipe(e) {
        console.log('closeSwipe', e)
        this.setData({isOpen: false})
        e.detail.instance.close() // 手动关闭
    },
    



})