// pages/order-list/order-list.js

import { getTotalPage, hideLoading, msg, navTo } from "@/utils/util"
import { toShoppingPage } from '@/utils/page'

const db = wx.cloud.database()

Page({

    data: {
        pageNum: 1, // 当前查询第几页
        pageSize: 5, // 每次查询最多的条数
        totalPage: 0, // 总页数
        orderList: [], // 订单数据
    },

    navTo,

    toShoppingPage,

    onShow() {
        // 每次显示此页面时，进行触发下拉刷新，从而查询订单列表数据
        wx.startPullDownRefresh()
    },

    // 下拉刷新时触发 
    onPullDownRefresh() {
        this.setData({ pageNum: 1 })
        this.loadOrderList()
    },

    // 页面上拉触底事件的处理函数
    onReachBottom() {
        this.setData({pageNum: this.data.pageNum + 1})
        this.loadOrderList()
    },

    // 分页查询订单列表数据
    async loadOrderList() {
        try {
            let { totalPage, pageNum, pageSize, orderList } = this.data

            // 如果不是第1次查询数据，且查询页码大于总页码，则不查询
            if (pageNum !== 1 && pageNum > totalPage) {
                return
            }

            // 查询总记录数, 注意 db 在最外面已经获取了
            const { total } = await db.collection('mxg_order').count()
            // console.log('total', total)

            // 分页查询订单数据（当前用户）
            const { data: newOrderList } = await db.collection('mxg_order')
                .limit(pageSize)
                .skip( (pageNum - 1) * pageSize )
                .orderBy('_createTime', 'desc')
                .get()
           
            // 计算总页数
            totalPage = getTotalPage(total, pageSize)

            // 第1页展示本次查询，如果是从2页开始则追加到原列表数据后面
            orderList = pageNum == 1 ? newOrderList : orderList.concat(newOrderList)

            this.setData({ totalPage, orderList })

            // console.log('newOrderList', totalPage, orderList)
        } catch (error) {
            console.error('查询订单列表数据失败', error)
            msg('查询订单失败')
        } finally {
           wx.stopPullDownRefresh()
        }
    },

    /** 用户点击右上角分享*/
    onShareAppMessage() {
    }

})