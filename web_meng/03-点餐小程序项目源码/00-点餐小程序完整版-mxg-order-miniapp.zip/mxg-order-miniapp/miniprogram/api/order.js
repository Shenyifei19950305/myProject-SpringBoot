/**
 * 新增订单数据
 * @param {Object} data 新增的订单数据
 */
export function addOrder(data) {
    return wx.cloud.callFunction({
        name: 'add',
        data: {
            collectionName: 'mxg_order',
            data
        }
    })
}