// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV }) // 使用当前云环境

const db = cloud.database()

// 云函数入口函数: 预登录，
exports.main = async (event, context) => {
  const { OPENID } = cloud.getWXContext()
 
  // 1. 通过 _openid 查询会员信息
  const { data } = await db.collection('mxg_member')
    .where({
        _openid: OPENID
    })
    .get()
  
    // 2. 存在，查询返回会员信息
    if (data && data.length > 0) {
        return data[0]
    }

    // 3. 不存在，注册新会员
    const member = {
        _openid: OPENID,
        isAdmin: false, // 是否为管理员
        _createTime: Date.now()
    }
    // 新增会员数据
    const created = await db.collection('mxg_member')
        .add({
            data: member
        })
    
    return member
}