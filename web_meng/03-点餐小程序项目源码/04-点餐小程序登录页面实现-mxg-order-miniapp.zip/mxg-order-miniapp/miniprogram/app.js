// app.js
App({

    onLaunch() {
        wx.cloud.init({
            env: 'mxg-order-miniapp-8ezp26957605b3', // 云开发环境id
            traceUser: true
        })
    },

    memberInfoKey: 'member_info',
    
    // 保存会员信息到storage中
    storageMember(member) {
        wx.setStorageSync(this.memberInfoKey, member)
    },

    current() {
        return {logined: false}
    }
})
