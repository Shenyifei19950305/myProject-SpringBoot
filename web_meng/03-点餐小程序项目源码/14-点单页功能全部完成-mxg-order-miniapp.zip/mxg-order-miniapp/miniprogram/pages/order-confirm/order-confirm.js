// pages/order-confirm/order-confirm.js
Page({

    data: {
        orderData: {}, // 订单数据
    },

    onLoad(options) {
        // console.log('options', JSON.parse(options.orderData))
        if (options.orderData) {
           const orderData = JSON.parse(options.orderData)
           this.setData({ orderData })
        }
    }

})