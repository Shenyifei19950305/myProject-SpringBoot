
Page({

    data: {
        takeType: 1, // 1-到店自取，2-外送上门
        shop: null, //下单店铺
    },

    onShow(){
      const {takeType, shop} = getApp().pageData || {}
       console.log('takeType', takeType, shop)
      if (takeType) this.setData({ takeType })
      if (shop) this.setData({ shop })
      // 清除
      getApp().pageData = {}
    }
})