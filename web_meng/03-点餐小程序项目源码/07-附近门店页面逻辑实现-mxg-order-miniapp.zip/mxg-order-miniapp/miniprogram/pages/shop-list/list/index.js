// pages/shop-list/list/index.js

import { getMemberById } from '@/api/member'
import { getNearShopList } from '@/api/shop'
import { msg } from '@/utils/util'

Component({

    properties: {
        tabName: String, // 当前所在的标签名 near附近，collect收藏
        longitude: Number, // 地理位置经度
        latitude: Number,// 地理位置纬度
    },

    data: {
        loading: false,
        collectShopIds: [], // 收藏的门店ids
        shopList: [], // 门店列表数据
    },

    /* lifetimes: {
        attached() {
            this.getCollectShopIds()
        }
    },*/
    
    methods: {

        // 查询当前用户已收藏的门店ids
        async getCollectShopIds() {
            const {member} =  getApp().current()
            if (!member || !member._id) return
            // 查询会员，collectShopIds字段保存了收藏的门店ids
            const { data } = await getMemberById(member._id)
            this.setData({ collectShopIds: data.collectShopIds || [] })
            console.log("getCollectShopIds", data)
        },

        // 查询门店列表
        async loadShopList () {
            try {
                this.setData({ loading: true })

                // 1. 查询当前用户已收藏的门店ids
                await this.getCollectShopIds()
                
                // 2. 根据当前用户位置，查询距离由近到远的门店列表数据
                const { tabName, longitude, latitude, collectShopIds } = this.data
                let shopList = [] // 门店列表数据
                if (tabName == 'near') {
                    // 查询附近门店
                    const { list } = await getNearShopList(longitude, latitude)
                    shopList = list
                } else if (collectShopIds && collectShopIds.length > 0) {
                    // 查询收藏门店
                    const { list } = await getNearShopList(longitude, latitude, collectShopIds)
                    shopList = list
                }

                // 数据格式转换：将m转成km
                shopList.forEach(item => {
                    // 将m转成km , 
                    const distance = Math.round(item.distance || 0)
                    item.distanceStr = distance < 1000 ? distance + 'm' : (distance/1000).toFixed(2) + 'km'
                    // 判断是否此门店是否已收藏, true已收藏，false未收藏
                    item.collected = collectShopIds.includes(item._id)
                })
                
                console.log("loadShopListxxxxx", shopList)
                this.setData({ shopList: shopList })

                // 3. 更新地图上标点信息
                this.triggerEvent('updateMapMarkers', { shopList })
            } catch (error) {
                console.error('查询门店列表异常', error)
                msg('门店查询失败')
            } finally {
                this.setData({ loading: false })
            }
        }
    }

})