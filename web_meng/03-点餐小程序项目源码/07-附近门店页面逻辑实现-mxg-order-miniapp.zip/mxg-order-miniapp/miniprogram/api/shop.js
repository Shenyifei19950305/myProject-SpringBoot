/**
 * 查询由近到远的门店数据 
 * @param {*} longitude 经度
 * @param {*} latitude 纬度
 * @param {*} shopIds 门店ids
 */
export async function getNearShopList(longitude, latitude, shopIds) {
    const { result } = await wx.cloud.callFunction({
        name: 'getNearShopList',
        data: {
            longitude, 
            latitude, 
            shopIds
        }
    })
    return result
}