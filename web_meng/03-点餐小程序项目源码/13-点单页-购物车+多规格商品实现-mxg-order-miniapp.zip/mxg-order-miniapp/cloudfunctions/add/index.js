// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV }) // 使用当前云环境

const db = cloud.database()

// 云函数入口函数: 通用的新增数据
exports.main = async (event, context) => {
    const { OPENID: openId } = cloud.getWXContext()
    const { collectionName, data } = event

   return await db.collection( collectionName ).add({
        data: {
            _createTime: Date.now(),
            _updateTime: Date.now(),
            _openid: openId,
            ...data
        }
    })
}