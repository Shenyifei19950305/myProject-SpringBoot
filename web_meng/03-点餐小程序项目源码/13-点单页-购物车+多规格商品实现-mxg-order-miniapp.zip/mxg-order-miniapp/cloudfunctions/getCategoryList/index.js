// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV }) // 使用当前云环境

const db = cloud.database()

// 云函数入口函数: 查询商品分类
exports.main = async (event, context) => {
  
    // 查询商品分类 list: [{_id: '分类1'}, {_id: '分类2'}]
    return await db.collection('mxg_goods').aggregate()
        .group({ // 分组统计，将商品中对应category字段查询出来放到_id中，并且会去重：重复名称只保留一个
            _id: '$category'
        })
        .sort({
            _id: 1, // 1 代表升序排列（从小到大）； -1 代表降序排列（从大到小）
        })
        .end()

}