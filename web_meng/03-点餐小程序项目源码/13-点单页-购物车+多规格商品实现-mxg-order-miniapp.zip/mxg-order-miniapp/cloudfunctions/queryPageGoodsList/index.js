// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV }) // 使用当前云环境

const db = cloud.database()

// 云函数入口函数
exports.main = async (event, context) => {
    const { keyword, pageNum = 1, pageSize = 100 } = event
    
    // 封装模糊查询条件
    let data = {}
    if (keyword && keyword.trim().length > 0) {
        data = {
            goodsName: db.RegExp({
                regexp: keyword.trim(), // " xxx   "
                options: 'i',
            })
        }
    }
    
    // 查询总记录数
    const { total } = await db.collection('mxg_goods')
        .where(data)
        .count()

    // 分页查询商品数据
    const { data: goodsList } = await db.collection('mxg_goods')
        .where(data)
        .limit(pageSize) // 每次最多返回的记录数
        .skip( (pageNum-1) * pageSize ) // 跳过前面多条数据
        .orderBy('category', 'asc')
        .get()
    
    return { total, goodsList }
}