

/**
 * 新增收货地址信息
 * @param {Object} data 新增的地址对象
 */
export function addAddress(data) {
    return wx.cloud.callFunction({
        name: 'add',
        data: {
            collectionName: 'mxg_address',
            data
        }
    })
}

/**
 * 通过地址id查询地址详情
 * @param {String} id 地址id
 */
export function getAddressById(id) {
   return wx.cloud.callFunction({
        name: 'getById',
        data: {
            collectionName: 'mxg_address',
            id // id: id
        }
    })
}

/**
 * 更新地址
 * @param {String} id 地址id
 * @param {Object} data 更新之后的地址对象
 */
export function updateAddress(id, data) {
    return wx.cloud.callFunction({
        name: 'updateById',
        data: {
            collectionName: 'mxg_address',
            id, // id: id
            data
        }
    })
}