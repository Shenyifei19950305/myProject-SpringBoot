
/**
 * 查询商品分类数据
 */
export async function getCategoryList() {
    const { result } = await wx.cloud.callFunction({
        name: 'getCategoryList'
    })
    return result
}

/**
 * 分页查询商品列表
 * @param {number} pageNum 1
 * @param {number} pageSize 100
 * @param {string} keyword 查询条件值
 */
export async function queryPageGoodsList(pageNum = 1, pageSize = 100, keyword) {
    const { result } = await wx.cloud.callFunction({
        name: 'queryPageGoodsList',
        data: {
            pageNum,
            pageSize,
            keyword
        }
    })
    return result
}
