// pages/address-edit/address-edit.js
import {hideLoading, isNull, msg, navBack, showLoading} from '@/utils/util'
import { addAddress, getAddressById, updateAddress } from '@/api/address'

Page({

    data: {
        id: '',
        name: '', //姓名
        sex: 1, // 1 先生，2女士
        mobile: '', // 手机号
        locationName: '',// 位置名称
        address: '', // 完整地址
        longitude: 0, // 位置经度
        latitude: 0, // 位置纬度
        streetNumber: '', // 门牌号
        error: {} , // 校验错误信息对象
    },

    onLoad(options) {
        const {id = ''} = options
        this.setData({ id })

        // 设置导航栏标题
        wx.setNavigationBarTitle({
          title: id ? '修改地址': '新增地址',
        })

        this.loadData(id)
    },

    async loadData(id) {
        if (!id) return 
        console.log('查询详情数据')
        try {
            showLoading()
            const { result } = await getAddressById(id)
            const { name, sex, mobile, locationName, longitude, latitude, streetNumber } = result.data
            this.setData({
                name, sex, mobile, locationName, longitude, latitude, streetNumber
            })
            // console.log('result', result)
        } catch (error) {
            console.error('地址查询失败', error)
            msg("地址查询失败", {icon: 'error'})
        } finally {
            hideLoading()
        }
    },

    // 打开地图：选择收货地址
    async handleLocation() {
        // console.log('handleLocation')
        const { name, address, longitude, latitude,  } = await wx.chooseLocation()
        this.setData({
            locationName: name,
            address,
            longitude,
            latitude
        })
    },

    handleConfirm() {
        console.log('handleConfirm')
        // 检验是否为空
        const {name, sex, mobile, locationName, longitude, latitude, streetNumber} = this.data
        let error = {} // 封装校验错误信息对象
        if (isNull(name)) error.name = '联系人姓名不能为空'
        if (isNull(sex)) error.sex = '性别为必选项'
        if (isNull(mobile)) error.mobile = '手机号不能为空'
        if (isNull(locationName, longitude, latitude)) error.locationName = '地址不能为空'
        if (isNull(streetNumber)) error.streetNumber = '门牌号不能为空'
        this.setData({ error })

        if (Object.keys(error).length > 0) return 

        // 新增或更新地址数据
        this.addOrUpdate()
    },

    // 调用新增或更新的接口
    async addOrUpdate() {
        try {
            showLoading('提交中')
            const {
                id, name, sex, mobile, locationName, address, 
                longitude, latitude, streetNumber
            } = this.data
            // 封装要保存的数据
            const data = { name, sex, mobile, locationName, address, 
                longitude, latitude, streetNumber }

            let res
            if (id) { // 修改
                res = await updateAddress(id, data)
            } else { // 新增
                // 新增数据
                res = await addAddress(data)
            }
            console.log('res', res)
            msg('保存成功', {icon: 'success'})
            // 后退
            navBack()
        } catch (error) {
            console.error('保存失败', error)
            msg('保存失败', {icon: 'error'})
        } finally {
            hideLoading()
        }
        
    }

})