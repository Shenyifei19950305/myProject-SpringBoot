// app.js
App({

    onLaunch() {
        wx.cloud.init({
            env: 'mxg-order-miniapp-8ezp26957605b3', // 云开发环境id
            traceUser: true
        })
    },
    
    current() {
        return {logined: true}
    }
})
