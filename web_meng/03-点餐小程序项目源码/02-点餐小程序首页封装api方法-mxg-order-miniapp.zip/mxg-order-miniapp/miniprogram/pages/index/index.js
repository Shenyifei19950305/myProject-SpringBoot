// index.js
import { navTo, showLoading, hideLoading } from '@/utils/util'
import { toOrderPage, toShoppingPage } from '@/utils/page'
import { getAdvertList } from '@/api/advert'

Page({
    
  data: {
    bannerList: [1, 2, 3],
    member: null, // 登录会员信息
    logined: false, // 是否已登录
    hotList: [1, 2, 3, 4] // 热门推荐数据
  },

  navTo, // 页面跳转， navTo: navTo

  toOrderPage, // 跳转到订单页 toOrderPage: toOrderPage

  // 跳转到点击页面
  toShoppingPage(e) {
      const { takeType } = e.currentTarget.dataset
      console.log('toShoppingPage', takeType)
      toShoppingPage( {takeType} )
  },

  async onLoad() {
    try {
        showLoading()
        this.loadAdvertList('1') // 首页轮播图
        await this.loadAdvertList('2') // 首页热门推荐
    } catch (error) {
        console.error('首页查询数据异常', error)
    } finally {
        hideLoading()
    }
  },

  async loadAdvertList(position) {
    const { data } = await getAdvertList(position)
    // console.log('res', data)
    if (position == '1') this.setData({bannerList: data})
    if (position == '2') this.setData({hotList: data})
  }

})
