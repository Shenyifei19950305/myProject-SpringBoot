
Page({

    data: {
        takeType: 1, // 1-到店自取，2-外送上门
    },

    onShow(){
      const {takeType} = getApp().pageData
    //   console.log('takeType', takeType)
      if (takeType) this.setData({ takeType })
      // 清除
      getApp().pageData = {}
    }
})