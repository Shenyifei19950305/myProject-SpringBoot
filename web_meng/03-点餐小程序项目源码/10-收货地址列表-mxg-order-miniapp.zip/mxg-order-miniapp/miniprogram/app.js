import { navTo } from "@/utils/util"

// app.js
App({

    onLaunch() {
        wx.cloud.init({
            // env: 'mxg-order-miniapp-8ezp26957605b3', // 云开发环境id
            env: 'mxg-order-miniapp-9e6g5965797ba7', // 云开发环境id
            traceUser: true
        })
    },

    memberInfoKey: 'member_info',
    
    // 保存会员信息到storage中
    storageMember(member) {
        wx.setStorageSync(this.memberInfoKey, member)
    },

    /**
     * 获取当前登录信息
     * @param {boolean} mustLogin 是否必须登录，未登录时，则跳转登录页
     */
    current(mustLogin = false) {
        // 获取本地保存的登录会员信息
        const member = wx.getStorageSync(this.memberInfoKey)

        // 判断是否登录成功：如果有手机号，则表示登录成功
        const logined = !!(member && member.mobile)
        if (mustLogin && !logined) {
            navTo("/pages/login/login")
            return
        }
        return {logined, member}
    },

})
