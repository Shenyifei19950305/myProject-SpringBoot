
/**
 * 上传文件到云存储
 * @param {*} tempFilePath 要上传文件的本地文临时路径
 * @param {*} fileType 文件类型：image/vedio/file 等，用于设置存放在云上的路径
 */
export function uploadFile(tempFilePath, fileType='image') {
    // http://xxxx.png  image/xxxx.png
    const cloudPath = fileType + 
        tempFilePath.substring(tempFilePath.lastIndexOf('/')).replace('tmp_', '')
    //console.log('cloudPath', cloudPath)
    return wx.cloud.uploadFile({
        cloudPath: cloudPath, // 上传到云端的路径 
        filePath: tempFilePath, // 要上传文件的本地文临时路径 
    })
}