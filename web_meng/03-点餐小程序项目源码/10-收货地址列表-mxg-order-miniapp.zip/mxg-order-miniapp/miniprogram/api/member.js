
/**
 * 通过会员id查询会员信息
 * @param {string} id 会员id
 */
export async function getMemberById(id) {
    const { result } = await wx.cloud.callFunction({
        name: 'getById',
        data: {
            id, 
            collectionName: 'mxg_member'
        }
    })
    return result
}

/**
 * 通过文档id更新会员数据
 * @param {string} id 会员id
 * @param {Object} data 更新之后的数据对象
 */
export function updateMemberById(id, data) {
    return wx.cloud.callFunction({
        name: 'updateById',
        data: {
            collectionName: 'mxg_member',
            id,
            data
        }
    })
}

/**
 * 更新会员余额
 * @param {*} id 会员id
 * @param {*} rechargeAmount 充值金额
 */
export function updateBalance(id, rechargeAmount) {
    return wx.cloud.callFunction({
        name: 'updateBalance',
        data: {
            id,
            rechargeAmount
        }
    })
}