
/**
 * 查询指定位置的广告数据
 * @param {*} position 位置 '1' 首页轮播图，'2' 首页热门推荐, '3' 点单页轮播图
 */
export async function getAdvertList(position) {
    const { result } = await wx.cloud.callFunction({
        name: 'getAdvertList', // 云函数名称
        data: { // 传递的数据
            position, //position: position
        }
    })
    return result
}