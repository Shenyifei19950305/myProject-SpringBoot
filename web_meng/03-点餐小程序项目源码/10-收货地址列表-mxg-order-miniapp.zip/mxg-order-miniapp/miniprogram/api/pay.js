/**
 * 发送微信支付功能
 * @param {*} body 商品描述
 * @param {*} orderNo 订单号
 * @param {*} totalAmount 支付金额
 * @param {*} callFunctionName 回调云函数名称
 */
export async function wxpay(body, orderNo, totalAmount, callFunctionName) {
    // 1. 调用云函数：微信支付统一下单接口
    const res = await wx.cloud.callFunction({
        name: 'wxpayCloud',
        data: {
            body, 
            orderNo, 
            totalAmount, 
            callFunctionName
        }
    })
    console.log('调用支付下单云函数响应结果', res)
    // 2. 调用支付api wx.requestPayment 发起支付请求，带上统一下单返回payment对象作为参数即可
    const { payment } = res.result
    return wx.requestPayment(payment)
}