/**
 * 查询由近到远的门店数据 
 * @param {*} longitude 经度
 * @param {*} latitude 纬度
 * @param {*} shopIds 门店ids
 */
export async function getNearShopList(longitude, latitude, shopIds) {
    const { result } = await wx.cloud.callFunction({
        name: 'getNearShopList',
        data: {
            longitude, 
            latitude, 
            shopIds
        }
    })
    return result
}

/**
 * 更新会员的收藏店铺ids
 * @param {string} memberId 会员id
 * @param {string} shopId 收藏或取消收藏的门店id
 * @param {boolean} collected true添加收藏，false取消收藏
 */
export function updateCollectShopIds(memberId, shopId, collected) {
    return wx.cloud.callFunction({
        name: 'updateCollectShopIds',
        data: {
            memberId, 
            shopId, 
            collected
        }
    })
}