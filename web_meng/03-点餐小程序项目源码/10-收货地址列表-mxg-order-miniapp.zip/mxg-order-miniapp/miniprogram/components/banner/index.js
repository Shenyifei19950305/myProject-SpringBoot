// components/banner/index.js
Component({
    options: {
        styleIsolation: "shared"
    },
    // 接收父组件传递的数据
    properties: {
        list: { // 轮播数据
            type: Array,
            value: []
        },
        height: { // 轮播图高度
            type: String,
            value: '500rpx'
        },
        dotsBottom: { // 指示点到底部距离
            type: String,
            value: '18rpx'
        }
    }
})