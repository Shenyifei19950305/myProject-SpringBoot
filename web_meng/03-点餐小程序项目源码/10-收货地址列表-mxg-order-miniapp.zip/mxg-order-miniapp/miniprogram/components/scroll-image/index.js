// components/scroll-image/index.js

Component({

    options: {
       addGlobalClass: true 
    },

    properties: {
        title: {
            type: String, 
            value: '推门推荐'
        },
        rightText: {
            type: String, 
            value: '更多'
        },
        list: {
            type: Array,
            value: []
        }
    },

    methods: {
        // 点击右侧文字（更多>），触发此方法
        handleRight() {
            // 触发父组件的right事件
            this.triggerEvent('right')
        }
    }

})