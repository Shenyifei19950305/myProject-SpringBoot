import { msg } from "@/utils/util"

// pages/address-list/address-list.js
Page({

    data: {
        checkedId: '', // 选中的地址id
        addressList: [
            {
                _id: 1, 
                locationName: '腾王阁', 
                streetNumber: '1101室201',
                name: '张三', 
                mobile: '18889999123'
            },
            {
                _id: 2, 
                locationName: '腾王阁', 
                streetNumber: '1101室201',
                name: '张三', 
                mobile: '18889999123'
            }
        ]
    },

    onLoad(options) {
        this.setData({checkedId: options.addressId || ''})
    },
    
    onShow() {
        // 触发下拉刷新
        wx.startPullDownRefresh()
    },

    // 当下拉刷新后会进行触发
    onPullDownRefresh() {
        this.loadList()
    },

    async loadList() {
       try {
           // 清空原选中的地址id
            this.setData({ checkedId: '' })

            const { data: addressList } = await wx.cloud.database()
                .collection('mxg_address').get()

            this.setData({ addressList })
            // console.log('addressList', addressList)
       } catch (error) {
           console.error('查询地址信息失败', error)
           msg('查询数据失败', {icon: 'error'})
       } finally {
           // 停止下拉刷新动画
           wx.stopPullDownRefresh()
       }
    }

})