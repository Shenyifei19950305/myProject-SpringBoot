// pages/member-code/member-code.js

// 1. 导入生成码的工具方法
import {barcode, qrcode} from '@/utils/wxbarcode/index'
Page({

    data: {
        defaultLight: 1, // 屏幕的高亮值0-1
        code: '' // 会员码
    },
  
    onLoad() {
        // 获取会员卡号
       const { member } = getApp().current()
       const code = member.cardNo || '1111888888'
       this.setData({ code })

       // 生成条形码：参数1  canvas-id值，参数2 条码值，参数3/4: 宽/高
       barcode('barcode', code+'', 600, 200)

       // 生成二维码：参数1  canvas-id值，参数2 二维码值，参数3/4: 宽/高
       qrcode('qrcode', code+'', 400, 400)
    },

    onShow() {
        // 1. 获取当前的屏幕亮度
        wx.getScreenBrightness({
            success: (res) => {
                console.log('res', res)
                // 记录当前屏幕，后退时恢复原始亮度
                this.setData({defaultLight: res.value})
                // 2. 设置屏幕亮度最亮
                wx.setScreenBrightness({
                    value: 0.7, // 取值0-1, 0最暗，1最亮
                })
            }
        })
       
    },

    onUnload() {
        // 页面销毁时触发，将原始亮度恢复
        wx.setScreenBrightness({
          value: this.data.defaultLight,
        })
    }

})