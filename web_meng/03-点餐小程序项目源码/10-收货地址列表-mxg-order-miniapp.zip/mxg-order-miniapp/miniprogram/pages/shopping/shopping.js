import { navTo } from "@/utils/util"
import { getAdvertList }  from "@/api/advert"

Page({

    data: {
        navHeight: 0, // 导航栏的高度
        showSearchInput: false, // 是否显示搜索输入框
        takeType: 1, // 1-到店自取，2-外送上门
        shop: null, //下单店铺
        bannerList: [],
        address: null, //收货地址
    },

    onShow(){
      const {takeType, shop} = getApp().pageData || {}
       console.log('takeType', takeType, shop)
      if (takeType) this.setData({ takeType })
      if (shop) this.setData({ shop })
      // 清除
      getApp().pageData = {}
    },

    onLoad() {
        this.loadAdvertList()
    },
    
    navTo,

    toSearchPage() {
        navTo('/pages/search/search')
    },

    // 查询 点单页轮播图数据
    async loadAdvertList() {
        // '3' 点单页轮播图
        const { data } = await getAdvertList('3')
        this.setData({ bannerList: data }, this.selectorQueryStickyTop)
    },

    // 点单信息区域吸顶
    scrollShopInfoSticky(e) {
        const { isFixed } = e.detail
        this.setData({ showSearchInput: isFixed })
    },

    // 切换取单类型
    changeTakeType(e) {
        const {takeType} = e.currentTarget.dataset
        this.setData({ takeType })
    },

    // 去选择收货地址页面
    toSelectAddress() {
        console.log('toSelectAddress')
        const addressId = this.data.address?._id || ''
        navTo('/pages/address-list/address-list?addressId='+addressId, {
            events: { // 添加一个事件,用于获取被打开页面传递到当前页面的数据
                updateAddress: (address) => {
                    console.log('address', address)
                    this.setData({ address })
                }
            }
        })
    },

    // 获取分类列表滚动吸顶时需要使用的距离顶部高度 top=导航栏高度+点单信息区域高度
    selectorQueryStickyTop() {
        wx.createSelectorQuery().select('#shop-info-id').boundingClientRect((res) => {
            // console.log('res', res)
            // 导航栏高度+点单信息区域高度
            this.setData({ stickyTop: this.data.navHeight + res.height })
        }).exec() // 不要少了
    }

})