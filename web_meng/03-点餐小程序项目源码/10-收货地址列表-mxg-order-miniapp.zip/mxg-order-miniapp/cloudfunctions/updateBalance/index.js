// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV }) // 使用当前云环境

const db = cloud.database()
const _ = db.command

// 云函数入口函数: 更新会员余额
exports.main = async (event, context) => {
    // 会员id, 充值金额
    const {id, rechargeAmount} = event

    // 更新会员余额
    return await db.collection('mxg_member')
        .doc(id)
        .update({
            data: {
                // _.inc将balance字段值自增rechargeAmount值，小数有精度的问题，可以元转换为分进行整数存储
                // 注意：上面要声明const _ = db.command
                balance: _.inc(rechargeAmount) 
            }
        })
}