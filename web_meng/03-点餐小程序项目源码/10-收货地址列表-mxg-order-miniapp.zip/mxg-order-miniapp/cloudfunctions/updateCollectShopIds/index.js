// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV }) // 使用当前云环境


// 云函数入口函数: 更新会员收藏门店id(_.addToSet)或取消门店id(_.pull)
const db = cloud.database()
const _ = db.command
exports.main = async (event, context) => {
    // collected 为true表示收藏，false表示取消收藏
    const { memberId, shopId, collected } = event

    return await db.collection('mxg_member')
        .doc(memberId)
        .update({
            data: {
                // collected ? shopId添加到collectShopIds数组字段中 ： 从collectShopIds数组字段移除shopId 
                collectShopIds: collected ? _.addToSet(shopId) : _.pull(shopId)
            }
        })
}