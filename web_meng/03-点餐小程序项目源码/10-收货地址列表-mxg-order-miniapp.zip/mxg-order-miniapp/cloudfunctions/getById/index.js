// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV }) // 使用当前云环境

const db = cloud.database()

// 云函数入口函数: 实现通过文档id查询指定集合的记录
exports.main = async (event, context) => {
    // id是文档id, collectionName要查询的集合名称
    const {id, collectionName} = event
    return await db.collection(collectionName).doc(id).get()
}