// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV }) // 使用当前云环境

// 获取数据库实例
const db = cloud.database()

// 云函数入口函数：查询指定位置的广告信息
exports.main = async (event, context) => {
    // '1' 首页轮播图，'2' 首页热门推荐, '3' 点单页轮播图
    const { position } = event
    return await db.collection('mxg_advert')
        .where({
            position: position, // 位置编号
            state: true // 正常状态
        })
        .orderBy('sort', 'asc') // 按sort字段升序排列（从小到大）
        .get()
}