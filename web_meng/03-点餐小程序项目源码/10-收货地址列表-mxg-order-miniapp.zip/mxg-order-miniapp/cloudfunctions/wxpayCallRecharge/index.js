// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV }) // 使用当前云环境

// 云函数入口函数：账户充值微信支付回调结果云函数
exports.main = async (event, context) => {
  const {returnCode} = event
  if (returnCode == 'SUCCESS') {
    // 支付成功， 一定要返回下面对象，微信后台才不会再次回调此云函数
    return {errcode: 0, errmsg: 'SUCCESS'}
  } else {
    // 支付失败, errcode返回非0则下次还是会回调
    return {errcode: -1, errmsg: 'FAIL'}
  }
}
