// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV }) // 使用当前云环境

const db = cloud.database()

// 云函数入口函数: 通过文档id 更新指定集合的记录
exports.main = async (event, context) => {
    // collectionName 集合名称, id 文档id, data 更新后的数据对象
    const {collectionName, id, data} = event

    return await db.collection(collectionName).doc(id)
        .update({
            data: data
        })
}