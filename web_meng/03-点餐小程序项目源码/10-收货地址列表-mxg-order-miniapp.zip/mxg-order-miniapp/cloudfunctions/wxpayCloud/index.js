// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV }) // 使用当前云环境

/**
 * 1、生成预支付订单 https://developers.weixin.qq.com/miniprogram/dev/wxcloudservice/wxcloud/reference-sdk-api/open/pay/CloudPay.unifiedOrder.html
 */

const config = {
    subMchId: 'xxxx', // 填写自己的微信支付商户id
    spbillCreateIp: '127.0.0.1'
}

// 云函数入口函数: 发起支付向微信支付后台生成预支付订单
exports.main = async (event, context) => {
    const { ENV } = cloud.getWXContext()
    const {body, orderNo, totalAmount, callFunctionName} = event
    // 向微信支付后台发起生成预支付订单
    const res = await cloud.cloudPay.unifiedOrder({
        body, // 商品描述
        outTradeNo: orderNo,// 商户业务订单号
        totalFee: totalAmount * 100, // 支付的总金额，单位是分，传递的是元，所以要转换成分 * 100
        spbillCreateIp: config.spbillCreateIp, // 终端 IP
        subMchId: config.subMchId, //商户号
        envId: ENV, // 支付结果回调云函数的环境ID
        functionName: callFunctionName // 支付结果通知回调云函数名
    })
    return res
}