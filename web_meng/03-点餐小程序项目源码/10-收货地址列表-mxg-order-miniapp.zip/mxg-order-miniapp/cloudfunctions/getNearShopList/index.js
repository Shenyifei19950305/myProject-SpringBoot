// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV }) // 使用当前云环境


/**
 * 云函数入口函数: 查询距离用户由近到远的门店列表
 * Aggregate.geoNear(options: Object): Aggregate
 * https://developers.weixin.qq.com/miniprogram/dev/wxcloudservice/wxcloud/reference-sdk-api/database/aggregate/Aggregate.geoNear.html
 */
const db = cloud.database()
const _ = db.command

exports.main = async (event, context) => {
    // longitude经度, latitude纬度, shopIds收藏的门店ids
    const {longitude, latitude, shopIds} = event
 
    // 构建查询条件
    const query = {} // _id in (1, 2, 3)
    if (shopIds && shopIds.length > 0) query._id = _.in(shopIds)

    const res = await db.collection('mxg_shop').aggregate()
        .geoNear({
            spherical: true, // 固定写法，写true即可
            distanceField: 'distance', // 输出的每个记录中 distance 即是与给定点的距离值
            near: db.Geo.Point(longitude, latitude), // 指定用户的经纬度，
            key: 'location', // 若只有 location 一个地理位置索引的字段，则不需填
            includeLocs: 'location', // 若只有 location 一个是地理位置，则不需填
            query// query: query
        })
        .end()
    return res
}