import { navTo } from "@/utils/util"
import { getAdvertList }  from "@/api/advert"

Page({

    data: {
        navHeight: 0, // 导航栏的高度
        showSearchInput: false, // 是否显示搜索输入框
        takeType: 1, // 1-到店自取，2-外送上门
        shop: null, //下单店铺
        bannerList: []
    },

    onShow(){
      const {takeType, shop} = getApp().pageData || {}
       console.log('takeType', takeType, shop)
      if (takeType) this.setData({ takeType })
      if (shop) this.setData({ shop })
      // 清除
      getApp().pageData = {}
    },

    onLoad() {
        this.loadAdvertList()
    },
    
    navTo,

    toSearchPage() {
        navTo('/pages/search/search')
    },

    // 查询 点单页轮播图数据
    async loadAdvertList() {
        // '3' 点单页轮播图
        const { data } = await getAdvertList('3')
        this.setData({ bannerList: data })
    },

    // 点单信息区域吸顶
    scrollShopInfoSticky(e) {
        const { isFixed } = e.detail
        this.setData({ showSearchInput: isFixed })
    },

    // 切换取单类型
    changeTakeType(e) {
        const {takeType} = e.currentTarget.dataset
        this.setData({ takeType })
    },

    // 去选择收货地址页面
    toSelectAddress() {
        console.log('toSelectAddress')
    },


})