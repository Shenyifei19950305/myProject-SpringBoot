// pages/payment/payment.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    orderId: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    const {orderId} = options
    if (!orderId) return
    this.setData({orderId})
  },

})