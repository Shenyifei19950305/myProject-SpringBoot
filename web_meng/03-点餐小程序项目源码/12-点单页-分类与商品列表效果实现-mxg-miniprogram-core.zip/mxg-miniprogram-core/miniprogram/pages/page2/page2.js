
Page({
    onLoad(option) {
        console.log('page2', option)
    },
    navBack() {
        wx.navigateBack({
            delta: 2 // 指定返回上2个页面
        })
    }
})