
Page({

    onLoad(option) {
        // '/pages/route/route?paramA=111&paramB=222'
        // {paramA: "111", paramB: "222"}
        // 通过option接收路径参数
        console.log('获取跳转到route页面中的路径参数', option)
        
        // 通过事件监听器来获取上一个页面传递的数据
        // eventChannel 实例通过wx.navigateTo跳转过来才能获取到，不然是一个空对象{}
        const eventChannel = this.getOpenerEventChannel()
        //console.log('eventChannel', eventChannel)
        eventChannel.on('userInfoEvent', (data) => {
            console.log('接收到上一个页面传递的数据', data)
        })

        // 向上一个页面传递数据
        //eventChannel.emit('acceptData', {data: 'test'})
    },

    navBack() {
        // 向上一个页面传递数据
        const eventChannel = this.getOpenerEventChannel()
        eventChannel.emit('acceptData', {data: 'test2'})
        // 后退
        // wx.navigateBack()
        wx.navigateBack({
            delta: 1 // 默认值1
        })
    },

    navTo() {
        wx.navigateTo({
          url: '/pages/page2/page2',
        })
    },

    toPageByRedirectTo() {
        // wx.redirectTo 关闭当前页面，打开一个新页面（不可以跳转到tabar页面），路径后面支持路径参数
        // page?paramA=aaa
        wx.redirectTo({
            url: '/pages/page2/page2?paramA=aaa',
           // url: '/pages/shopping/shopping', // 不可以跳转到tabar页面
        })
    },

    toPageByReLaunch() {
        // wx.reLaunch 关闭所有页面（支持打开tabar页面），打开新的页面
        wx.reLaunch({
            //   url: '/pages/page2/page2',
          url: '/pages/shopping/shopping', // 可以跳转到tabar页面
        })
    }

})