Page({
    data: {
        color: 'blue'
    },

    onLoad(option) {
        // console.log('shopping--option', option)
    },
    onShow() {
        // 获取全局实例App, 再获取全局变量
        const app = getApp()
        console.log('app.goodsInfo', app.goodsInfo)
    }
})