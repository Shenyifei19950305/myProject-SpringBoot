Page({

    onLoad() {
    //    this.testShowLoading()
    },

    // 测试消息提示框
    testToast() {
        // 消息提示框
        wx.showToast({
          title: '成功',
          icon: 'loading', // success成功，error失败，none 不显示图标, loading加载中
          duration: 5000, // 默认是1500毫秒
          mask: true, // 是否显示透明蒙层，防止触摸穿透
        })

        setTimeout(() => {
            wx.hideToast() // 手动关闭消息提示框
        }, 2000)
    },

    // 测试对话框
    testShowModal() {
        // console.log('testShowModal')
        // 对话框
        wx.showModal({
            title: '提示',
            content: '确认删除吗？',
            showCancel: true, //是否显示 取消 按钮，默认true
            cancelText: '关闭',
            cancelColor: '#901212',
            editable: false, // 是否显示输入 框，默认false
            success(res) {
                console.log('res', res)
                if (res.confirm) {
                    console.log('用户点击确认')
                } else {
                    console.log('用户点击取消')
                }
            }
        })
    },

    // 测试加载框
    testShowLoading() {
        // wx.showLoading 显示加载中，必须手动调用 wx.hideLoading() 方法进行关闭加载框
        wx.showLoading({
            title: '加载中',
            mask: true // 默认是false, 是否显示透明蒙层，防止触摸穿透
        })

        setTimeout(() => {
            // 手动隐藏加载中
            wx.hideLoading()
        }, 2000)
    },

    // 测试显示操作菜单 
    testShowActionSheet() {
        // console.log('testShowActionSheet')
        wx.showActionSheet({
          itemList: ['微信支付', '支付宝', '银联支付'], // 最多支持6个选项值
          itemColor: '#990000', // 按钮的字体颜色
          success(res) {
              // 点击的下标，从上往下计算，从0开始
              const {tapIndex} = res
              console.log('showActionSheet.res', res, tapIndex)
          }
        })
    }

})