Page({

    onLoad() {

    },

    // 测试调用云函数
    testCallCloudFunction() {
        // 调用云函数
        wx.cloud.callFunction({
            name: 'helloworld', // 云函数名称
            data: { // 向云函数中传递数据
                a: 10,
                b: 20
            },
            success: (res) => {
                // 云函数的返回值在 res.result 中
                console.log('调用成功', res)
            },
            fail: (error) => {
                console.error('调用失败', error)
            }
        })
    },
    
    // 测试调用云函数-promise方式
    async testCallCloudFunctionByPromise() {
        // 调用云函数-- Promise
        /* wx.cloud.callFunction({
            name: 'helloworld', // 云函数名称
            data: { // 向云函数中传递数据
                a: 10,
                b: 20
            }
        }).then((res) => {
            console.log('调用成功2', res.result)
        }).catch((error) => {
            console.error('调用失败2', error)
        }) */

        // 基于 async + await, 注意：方法前加上async
        try {
            const { result } = await wx.cloud.callFunction({
                name: 'helloworld',
                data: {
                    a: 5,
                    b: 10
                }
            })
            console.log('调用成功3', result)
        } catch (error) {
            console.error('调用失败', error)
        }
    },

    // 调用云函数实现新增记录
    async addUserByCloudFun() {
        try {
            const res = await wx.cloud.callFunction({
                name: 'add01',
                data: { // 向云函数传递的数据，传递了一个addData对象
                    addData: {
                        nickname: '小快乐22',
                        sex: '2',
                        birthday: new Date('1992-03-11'),
                        mobile: '18811110000'
                    }
                }
            })
            console.log('调用add01云函数成功', res.result._id)
        } catch (error) {
            console.error('调用add01云函数异常', error)
        }
    },

    // 调用云函数实现：更新记录
    async updateUserByCloudFun() {
        const res = await wx.cloud.callFunction({
            name: 'update01',
            data: {
                id: '9bf3df136702013b0e1b6dbd27d97370', // 文档id
                mobile: '15533336666' // 更新后的手机号
            }
        })
        console.log('云函数更新记录响应结果', res.result)
    },

    // 调用云函数实现：删除记录
    async removeUserByCloudFun() {
        const {result} = await wx.cloud.callFunction({
            name: 'remove01',
            data: {
                id: 'fa71adc66702430b00000e7562261fdf'
            }
        })
        console.log('调用云函数删除记录响应结果', result.stats.removed)
    },


    // 调用云函数实现：查询记录
    async getUserByCloudFun() {
        const { result } = await wx.cloud.callFunction({
            name: 'get01'
        })
        console.log('云函数查询记录响应结果', result)
    },

    // 调用云函数实现：多表关联查询
    async queryMoreTableByLookup() {
        const res = await wx.cloud.callFunction({
            name: 'moreTableQuery'
        })
        console.log('lookup多表关联查询', res.result.list)
    }

})