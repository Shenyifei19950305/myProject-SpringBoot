
Page({

    data: {
        fileType: 'image',
        fileUrl: ''
    },

    // 选择上传的图片或视频
    chooseMedia() {
        wx.chooseMedia({
            count: 1, // 最多可选择的文件个数
            mediaType: ['image', 'video'], // image图片、video视频，mix可同时选择视频图片
            sourceType: ['album', 'camera'], //选择的来源：'album'相册中, 'camera' 相机拍摄
            maxDuration: 60, //最大拍摄时长，单位秒，取值3s~60s之间
            camera: 'back', // back 前置摄像头，front前置摄像头
            success: (res) => {
                // res.tempFiles是一个数组，存储的是选择的资源
                console.log('选择的资源为', res.tempFiles)
                // 获取选择的临时文件地址 res.tempFiles[0].tempFilePath
                const {fileType, size, tempFilePath} = res.tempFiles[0]
                // 上传到云端
                this.uploadFile(tempFilePath, fileType)
            }
        })
    },

    // 上传文件到云存储
    uploadFile(tempFilePath, fileType = 'image') {
        console.log('上传文件到云存储', tempFilePath, fileType)
        // 云端的路径，注意：不能以/开头，且不能出现连续的 /, 推荐使用英文字母+数字组合
        const cloudPath = fileType + tempFilePath.substring(tempFilePath.lastIndexOf('/')).replace('tmp_', '')
        // console.log(cloudPath) 
        //  video/F8Jr9TKjCTNX198918f40ecc7cab0fc4231adaf67c96.mp4

        // 上传到云存储，注意：是 wx.cloud开头
        wx.cloud.uploadFile({
            cloudPath, // 简写 cloudPath: cloudPath, // 上传至云端的路径
            filePath: tempFilePath, // 小程序临时文件路径
            success: (res) => { // 上传成功
                console.log('上传成功res', res.fileID)
                this.setData({
                    fileType: fileType,
                    fileUrl: res.fileID
                })
            }
        })
    },

    // 选择微信会话中的文件，并进行上传
    async chooseMessageFile() {
        // 选择微信会话中的文件
        const res = await wx.chooseMessageFile({
          count: 1, // 可以同时选择多少个文件上传
          type: 'file', // 指定选择的类型，file是可以选择除了图片和视频之外的其它的文件，image 只能选择图片文件，video	只能选择视频文件，all （默认值）从所有文件选择
          extension: ['doc', 'docx', 'ppt', 'pptx', 'pdf'], //限制上传文件的后缀名，仅设置type:file有效
        })
        console.log('选择的文件信息为', res)
        const {path, type} = res.tempFiles[0]
        // 上传到云存储
        this.uploadFile(path, type)
    },

    // 下载云端的图片或视频，保存到相册中
    async downloadMedia() {
        // console.log('下载', this.data.fileUrl)
        // 下载
        const res = await wx.cloud.downloadFile({
            fileID: this.data.fileUrl, // 指定云端文件id
        })
        console.log('下载云端文件成功', res)
        // tempFilePath 下载保存到本地的临时文件地址
        const {tempFilePath, header} = res
        let contentType = header['Content-Type']
        // ios真机上，contentType的值是一个数组，Content-Type: ['image/png']
        if (contentType instanceof Array) contentType = contentType[0]
        // console.log('contentType', contentType, contentType.split('/'))
        contentType = contentType.split('/')[0]
        this.setData({fileType: contentType})// 展示对应媒体组件video、image
        // 保存到系统相册
        this.saveToPhotosAlbum(tempFilePath, contentType)
    },

    // 保存图片或视频到系统相册
    async saveToPhotosAlbum(tempFilePath, fileType) {
        try {
            if(fileType == 'image') { // 图片
                await wx.saveImageToPhotosAlbum({
                    filePath: tempFilePath
                })
            } else if(fileType == 'video') { // 视频
                await wx.saveVideoToPhotosAlbum({
                  filePath: tempFilePath
                })
            } else { // 其他类型文件
                wx.showToast({
                  title: '不支持保存到相册',
                  icon: 'error'
                })
                return
            }
            wx.showToast({ title: '保存成功' })
        } catch (error) {
            console.error('保存失败', error)
            wx.showToast({ title: '保存失败', icon: 'error' })
        }
        
    },

    // 下载并预览文档
    async downloadDocument() {
        // 获取下载文件的云端文件id
        const { fileUrl } = this.data
        if (!fileUrl) {
            wx.showToast({
              title: '链接不能为空',
              icon: 'error'
            })
            return
        }
        // 1. 下载
        const res = await wx.cloud.downloadFile({
            fileID: fileUrl
        })
        console.log('下载文档成功', res)
        const {tempFilePath} = res

        // 2. 预览: 新打开一个页面进行预览文档
        wx.openDocument({
          filePath: tempFilePath, // 本地文件路径
          showMenu: true, // 显示右上角菜单按钮
        })
    },

    // 删除云端文件（图片、视频、文档等都可以）
    deleteFile() {
        // 获取要删除的云端文件id
        const {fileUrl} = this.data
        if(!fileUrl) return
        // 删除
        wx.cloud.deleteFile({
            fileList: [fileUrl] // 指定要删除的云端文件ids
        }).then((res) => {
            // fileList是删除的文件信息，其中的 status属性值为0表示删除成功
            const {fileList} = res
            console.log('删除成功', res)
            wx.showToast({ title: '删除成功！' })
        }).catch((error) => {
            console.error('删除失败', res)
            wx.showToast({
              title: '删除失败！',
              icon: 'error'
            })
        })
    }

})