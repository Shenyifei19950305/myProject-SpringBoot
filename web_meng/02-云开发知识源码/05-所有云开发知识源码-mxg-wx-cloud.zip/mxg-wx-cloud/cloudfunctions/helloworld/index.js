// 云函数入口文件
// 相关于小程序端中 wx.cloud
const cloud = require('wx-server-sdk')

// cloud.DYNAMIC_CURRENT_ENV 代表的是引用的云开发环境Id
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV }) // 使用当前云环境

// 云函数入口函数
/**
 * 
 * @param {*} event 包含了userInfo:{appId, openId}， 接收小程序端传递的数据
 * @param {*} context 
 */
exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext()
  const {userInfo, a, b} = event
  const sum = a+b
  return {
    // event,
    // openid: wxContext.OPENID,
    // appid: wxContext.APPID,
    // unionid: wxContext.UNIONID,
    sum
  }
}