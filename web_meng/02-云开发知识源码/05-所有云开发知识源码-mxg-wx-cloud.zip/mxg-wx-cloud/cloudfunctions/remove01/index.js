// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV }) // 使用当前云环境

// 云函数入口函数
exports.main = async (event, context) => {
    const { id } = event
    // 通过云函数实现对云数据库中的集合记录进行删除操作
    return await cloud.database().collection('mxg_user')
        .doc(id)
        .remove()
}