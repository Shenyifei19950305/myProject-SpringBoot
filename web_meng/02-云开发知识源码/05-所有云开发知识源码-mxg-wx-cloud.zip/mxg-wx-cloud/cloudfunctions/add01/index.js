// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV }) // 使用当前云环境

// 云函数入口函数
exports.main = async (event, context) => {
    const wxContext = cloud.getWXContext()
    //   实现新增用户数据 
    // 小程序端新增数据(以wx开头）： wx.cloud.database().collection('mxg_user').add({data: xx})
    // 云函数新增数据（不要以wx开头，直接cloud.xxx)
    console.log('云函数日志')
    const { addData } = event

    // 通过云函数新增的记录，不会自动添加_openid到记录中
    const res = await cloud.database().collection('mxg_user')
        .add({
            data: {...addData, _openid: wxContext.OPENID}
        })
    return res
}