// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV }) // 使用当前云环境

// 云函数入口函数
exports.main = async (event, context) => {
  const { id, mobile } = event
  // 实现云函数中更新云数据库的集合记录: 可以更新所有用户的记录
  return await cloud.database().collection('mxg_user')
    // .doc(id)
    .where({
        _id: id
    })
    .update({
        data: { // 要更新的数据
            mobile // 等价于 mobile: mobile
        }
    })
}