// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV }) // 使用当前云环境

// 云函数入口函数
exports.main = async (event, context) => {
    // 实现多表查询：aggregate().lookup()
    // 关联 goods(主表）、goods_specs（被关联的表） 查询所有商品及对应商品的规格信息
    // select g.*, gs.*  from goods g LEFT JOIN goods_specs gs ON g._id = gs.goodsId
    return await cloud.database().collection('goods') // 指定的是主表
        .aggregate().lookup({ // 进行联表查询
            localField: '_id',  // 指定主表中的主键字段，即 goods中的主键_id, 用于关联条件
            from: 'goods_specs', // 指定被关联的表名
            foreignField: 'goodsId', // 指定被关联表中的外键字段，即goods_specs中的goodsId字段，用于关联主表
            as: 'specsList' // goods_specs查询出来的记录所存放的字段名
        })
        .match({ // 相关于where，作为条件查询
            _id: '25e993b76704950e0e600f7f438ee6e6' // 筛选goods集合中的_id=xx的记录
        })
        .end() //aggregate 中一定要调用end方法结束
}