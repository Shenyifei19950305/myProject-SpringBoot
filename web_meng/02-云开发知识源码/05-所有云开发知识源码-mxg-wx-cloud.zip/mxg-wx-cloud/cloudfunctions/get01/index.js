// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV }) // 使用当前云环境

// 云函数入口函数
exports.main = async (event, context) => {
    // 通过云函数实现查询云数据库的集合记录
    // 直接return返回响应结果，调用方通过 result.data 获取数组数据
    // return await cloud.database().collection('mxg_user').get()

    // 解构 data 数组数据返回，调用方通过 result 获取的就是数组数据
    const { data } = await cloud.database().collection('mxg_user').get()
    return data
}