Page({
    
    onLoad() {
        // this.queryByWhereCommand()
        // this.queryByCommandAnd()
        // this.queryByCommandOr()
        // this.queryByCommandNot()
        this.queryByCommandNor()
    },

    /**
     * 基于 where 方法+ db.command 实现复杂的查询操作
     */
    async queryByWhereCommand() {
        const db = wx.cloud.database()
        const _ = db.command // 注意最后不要有括号，它不是一个方法，返回一个对象
        const { data } = await db.collection('mxg_user')
            .where({
                // age: 18
                // age: _.eq(18) // 等价于 age: 18, age等于18的条件
                // age: _.neq(18) // age不等于18的数据（其中包含了没有age的字段也会返回）
                // age: _.gt(18) // age大于18的数据
                // age: _.gte(18) // age 大于或等于18的数据
                // age: _.lt(18) // age小于18的数据
                // age: _.lte(18) // age小于或等于18的数据
                // age: _.in([18, 30]) // in方法接收一个数组，用于字段值在给定数组的条件，age等于18或等于30的数据
                age: _.nin([18, 30]) // nin方法接收一个数组, 用于字段值不在给定数组的条件，age不等于18和30的数据
            })
            .get()
        console.log('查询数据结果', data)
    },

    // 使用 and 逻辑与操作，来连接多个条件，要同时满足
    async queryByCommandAnd() {
        const db = wx.cloud.database()
        const _ = db.command

        const { data } = await db.collection('mxg_user')
            .where(
                // 需求1：查询 sex 等于 '2' 且 age ⼤于 18的⽤户
                // 方式1：对象中各字段组成了逻辑与的关系 ，且
                /* {
                    sex: '2',
                    age: _.gt(18)
                } */

                // 方式2：使用 and 接收一个数组操作符后，直接传递给where方法，数组中每一个对象就是一个条件，这些数组元素的关系是逻辑与的关系
                /* _.and([
                    {sex: '2'},
                    {age: _.gt(18)}
                ]) */

                // 查询 age ⼤于等于18 且⼩于30 的⽤户
                {
                    // age: _.and(_.gte(18), _.lt(30)), // 方式1：前置写法
                    // age: _.gte(18).and(_.lt(30)) // 方式2：流式写法
                    age: _.gte(18).lt(30) // 方式3：链式写法
                }
            )
            .get()
        console.log('command.and查询结果', data)
    },

    // 使用 command.or 逻辑或操作
    async queryByCommandOr() {
        const db = wx.cloud.database()
        const _ = db.command
        const { data } = await db.collection('mxg_user')
            /* .where(
                // 1. 单字段的 或查询：age ⼩于 18 或⼤于等于 30 的⽤户
                {
                    // age: _.or(_.lt(18), _.gte(30)) // 方式1: 前置写法，接收多个条件参数
                    // age: _.or([_.lt(18), _.gte(30)]) // 方式2: 前置写法，接收一个数组参数
                    age: _.lt(18).or(_.gte(30)) // 方式2：流式写法
                }
            ) */

            // 2. 多字段的或查询：age⼤于18岁 或 sex等于'1' 的⽤户
            .where(
                _.or([ // or 接收一个数组，数组中每个对象条件取 或 的关系 
                    {age: _.gt(18)},
                    {sex: '1'} // 等价于 {sex: _.eq('1')}
                ])
            )
            .get()

        console.log('command.or查询结果', data)
    },

    // 使用 command.not 逻辑非操作符
    async queryByCommandNot() {
        const db = wx.cloud.database()
        const _ = db.command
        const { data } = await db.collection('mxg_user')
            // 查询 age 不等于 18 的用户
            .where(
                {
                    // 会将不存在的字段记录也返回
                    // age: _.not( _.eq(18) ) //  等价于 age ：_.neq(18)
                    // _.exists(true) 存在 age 字段才会进行条件判断，如果不存在则直接被过滤掉
                    age: _.exists(true).and( _.not( _.eq(18) ) )
                }
            )
            .get()
        console.log('command.not查询结果', data)
    },

    // 使用 command.nor 逻辑 “都不” 操作符：指定条件中都不满足的记录会被查询出来
    async queryByCommandNor() {
        
        const db = wx.cloud.database()
        const _ = db.command
        const { data } = await db.collection('mxg_user')
            // 查询 age 不⼩于18且不⼤于30 的⽤户 (即：[18~30]间的数值)
            .where({
                // 注意：nor 会将不存在 age 字段的记录查询出来，如果需要age字段必须存在 _.exists 方法
                // age: _.nor([_.lt(18), _.gt(30)])
                age: _.exists(true).and(_.nor([_.lt(18), _.gt(30)])) // 必须存在age字段且age不小于18且不大于30的用户
            })
            .get()

        console.log('command.nor查询结果', data)
    }


})