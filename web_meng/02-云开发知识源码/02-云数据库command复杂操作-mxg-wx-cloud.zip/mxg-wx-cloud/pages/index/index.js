
Page({

    data: {
        userList: []
    },

    onLoad() {
        // this.loadUserInfo()
        // this.loadUserInfoByES6()
        // this.loadById()
        // this.loadByWhere()
        // this.testOrderBy()
        // this.queryCount()
        // this.testLimit()
        // this.testSkip()
        this.pageQuery(1, 15)
    },

    // 查询用户数据:传统方式
    loadUserInfo() {
        // 指定要操作的集合，在数据库控制台中修改权限：所有用户可访问
        wx.cloud.database().collection('mxg_user') 
            .get({ // 查询操作
                success: (res) => { 
                    // res是一个对象，其中有data属性就是查询到数据（数组）
                    console.log('查询数据成功', res, this)
                    this.setData({ 
                        userList: res.data
                    })
                },
                fail: (error) => {
                    console.error('查询数据失败', error)
                }
            }) 
    },

    // 查询用户数据: ES6 Promise方式
    async loadUserInfoByES6() {
        // 使用 ES6 Promise 风格
        /* wx.cloud.database().collection('mxg_user')
            .get() // 返回一个Promise
            .then((res) => { // 成功， res.data 是目标数据（数组）
                console.log('查询成功', res)
                this.setData({ userList: res.data })
            })
            .catch((error) => {
                console.error('查询失败', error)
            }) */
        
        // 使用 ES6 Promise 简写风格: async/await
        try {
            // 一定要在方法前面加上 async 
            const res = await wx.cloud.database().collection('mxg_user').get()
            console.log('查询成功：', res)
            this.setData({ userList: res.data })
        } catch (error) {
            console.error('查询失败：', error)
        }
    },

    async loadById() {
        try {
            // 通过文档id(_id)来查询记录
            // 注意：调用  doc 方法后，返回的 data是一个对象，不是一个数组
            const { data } = await wx.cloud.database().collection('mxg_user')
                .doc('9bf3df136702013b0e1b6dbd27d97370') // 指定文档id:  _id 查询数据
                .get()
            console.log('通过文档id查询成功', data)
        } catch (error) {
            console.error('通过文档id查询失败', error)
        }
    },

    // 通过 where 方法条件查询
    async loadByWhere() {
        try {
            // where条件查询，返回的 data 是一个数组，不是一个对象
            const { data } = await wx.cloud.database().collection('mxg_user')
                .where({ // where 接收一个对象，对象中的字段条件 是且的关系 ，要同时满足
                    nickname: '小刘',
                    sex: '2'
                })
                .get()
            console.log('where条件查询成功', data)
        } catch (error) {
            console.log('where条件查询失败', error)
        }
    },

    // 新增记录（新增用户）
    addUser() {
        // 使用 add 方法向指定集合中新增记录
        wx.cloud.database().collection('mxg_user')
            .add({
                // data属性指定要新增的记录数据
                data: {
                    //_id: '1111', // 可手动指定文档id, 如果未指定则系统会自动生成一个文档Id
                    nickname: '刘哥',
                    mobile: '18800002222',
                    sex: '1',
                    birthday: new Date('1989-08-10')
                },
                success: (res) => {
                    // 新增记录的文档id会返回 res: {_id: xxx}
                    console.log('新增成功, _id为', res._id)
                },
                fail: (error) => {
                    console.error('新增失败', error)
                },
                complete: (val) => { // 不管成功或失败，都会被调用
                    console.log('新增完成', val)
                }
            })
    },

    // 新增记录：基于 ES6 Promise 方法
    async addUserByES6() {
        try {
            // 使用 async / await 进行调用  add 新增操作
            const res = await wx.cloud.database().collection('mxg_user').add({
                data: {
                    nickname: '周先生',
                    mobile: '13399990000',
                    sex: '1'
                }
            })
            console.log('新增成功', res._id)
        } catch (error) {
            console.log('新增异常', error)
        } finally {
            console.log('最终会执行complete')
        }
       
    },

    // 更新用户：通过文档id进行更新
    async updateUserById() {
        try {
            // 更新响应结果：res: { stats: {updated: 0} }
            /**
             1. 调用api成功，不代表数据一定更新成功，具体成功更新了多少条数据 ，要查看 res.stats.updated 属性值，如果是0表示未更新数据，反之就是更新的记录数
             2. 更新记录默认情况下只允许更新自己新增的记录，不允许更新他人新增的记录,
                如果需要更新他人新增的记录，则需要使用后面讲解的【云函数】来实现
             3. 筛选条件不会将所有满足条件的记录过滤出来，而是只会将当前用户新增的记录下满足条件的记录过滤出来。
             4. 如果更新的数据和数据库中的数据一致，则updated返回的是0
             */
            const res = await wx.cloud.database().collection('mxg_user')
                // .doc('8df0e92f6701f69d0e17bc7b08647674') // 指定文档id进行更新操作（只能操作当前用户的记录）
                .where({ // 指定多个条件更新操作（只能操作当前用户的记录）
                   _id: '8df0e92f6701f69d0e17bc7b08647674'
                })
                .update({ 
                    data: { // 指定更新之后的数据
                        nickname: '1111',
                        sex: '2'
                    }
                })
            console.log("更新成功", res.stats.updated)
        } catch (error) {
            console.error('更新异常', error)
        }
    },

    // 替换记录：将整个记录替换为目标记录
    async setUserById() {
        try {
            // res : { stats: {updated: 1, created: 0}, _id: ""}
            const res = await wx.cloud.database().collection('mxg_user')
                // .doc('8df0e92f6701f69d0e17bc7b08647674')
                .doc('2222') // 文档id存在，则替换set中指定的data数据；如果不存在则新增set中的data数据
                .set({
                    data: { // 替换为下面的数据
                        nickname: '小亮',
                        sex: '2'
                    }
                })
            console.log('替换数据结果', res)
        } catch (error) {
            console.error('替换数据异常', error);
        }
       
    },

    // 通过文档id进行删除
    async removeById() {
        try {
            // res: {stats: {removed: 1}}
            // remove 默认情况下，只支持删除当前用户的数据，不允许删除他人的数据（可以使用【云函数】）
            // 并且不支持全量删除集合中的数据
            const res = await wx.cloud.database().collection('mxg_user')
                // .doc('9bf3df136702013b0e1b6dbd27d97370')
                .where({ // 删除满足条件的当前用户下的记录
                    sex: '1'
                })
                .remove()
                
            console.log('删除记录成功', res.stats.removed)
        } catch (error) {
            console.error('删除异常', error)
        }
    },

    // 测试按字段排序
    async testOrderBy() {
        // orderBy 接收两个参数，参数1：字段名，参数2：asc （升序，越大越靠后）、desc（降序，越大越靠前）
        const res = await wx.cloud.database().collection('mxg_user')
            .orderBy('birthday', 'asc') // 按birthday进行升序（由小到大撞排序）
            .orderBy('sex', 'desc') // 如果birthday进行升序排列后，有相同的birthday再按sex降序排列
            .get()
        console.log('按birthday升序排列结果', res.data)
    },

    /**
     * 查询满足条件的总记录数
     * @param {number} pageSize  每页显示多少条记录
     */
    async queryCount(pageSize = 3) {
        // 查询总记录数
        const { total } = await wx.cloud.database().collection('mxg_user').count()

        // 计算总页码：通过总记录数total 对 每页显示多少条pageSize 求余
        // 如果余数等于0，则是 total/pageSize的商值，如果余数不等于0，则是商值+1
        const totalPage = total % pageSize > 0 ? Math.floor(total/pageSize)+1 : Math.floor(total/pageSize)
        console.log('当前满足条件的总记录数为', total, totalPage)
    },

    // limit 实现每次查询指定条数的记录
    async testLimit() {
        // 默认在小程序端发送查询请求最多每次返回20条记录，使用【云函数】每次最多可返回1000条
        const { data } = await wx.cloud.database().collection('mxg_user')
            .limit(3) // 指定返回的最多记录数，
            .get()
        console.log('limit查询结果', data)
    },

    // skip 查询指定序列号的后一条结果开始返回
    async testSkip() {
        const {data} = await wx.cloud.database().collection('mxg_user')
            .skip(3) // 从指定序列号的下一个序列号开始返回数据，比如：指定3，则跳过前面3条，从第4条开始返回
            .get()
        console.log('skip指定后返回的结果', data)
    },

    /**
     * 分页查询
     * @param {*} pageNum 当前页码（查询第几页数据）
     * @param {*} pageSize 每页显示多少条（每次查询多少条数据）
     */
    async pageQuery(pageNum = 1, pageSize = 10) {
        const {data} = await wx.cloud.database().collection('mxg_user')
            // .limit(3) // 每次最多查询3条数据（每页显示3条）pageSize
            // .skip(6) // 第1页：序列号为0，第2页：序列号为3，第3页：序列号6
            .limit(pageSize)
            .skip( (pageNum - 1) * pageSize )
            .get()
    },
    

})