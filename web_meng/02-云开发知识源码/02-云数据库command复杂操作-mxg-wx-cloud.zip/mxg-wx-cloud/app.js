// app.js
App({
  
    onLaunch() {

        // 云开发初始化：用于指定使用的云开发环境
        wx.cloud.init({
            env: 'mxg-order-miniapp-8ezp26957605b3', // 指定云开发的环境Id，后续调用云开发api时，所使用的环境就是此环境id，
            traceUser: true, // 是否将用户访问日志记录到用户管理中（在开发控制台中的【运营分析】》【用户访问】中可见
        })

    }

})
