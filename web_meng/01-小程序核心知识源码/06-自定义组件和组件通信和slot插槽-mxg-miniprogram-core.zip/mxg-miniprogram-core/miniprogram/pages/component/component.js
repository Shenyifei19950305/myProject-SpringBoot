
Page({
    data: {
        bannerList: [
            'https://emoji.bj.bcebos.com/yige-aigc/index_aigc/final/toolspics/pc_aigc.png',
            'https://emoji.bj.bcebos.com/yige-aigc/index_aigc/final/toolspics/0.png'
        ],
        name: '梦学谷',
        message: '父组件数据'
    },

    handleNavTo(e) {
        // e: {detail: 1111}
        console.log('父组件接收到的数据', e.detail)
    },

    // 自定义事件处理函数
    searchGoodsHandle(e) {
        // {keyword: this.data.keyword, price: 100}
        console.log('父组件searchGoodsHandle', e.detail) 
        const {keyword, name} = e.detail
        this.setData({
            name: name
        })
    },

    getChildComponent() {
        // 获取 id 为 my-component 的子组件实例对象(子组件 this)
        const child = this.selectComponent('#my-component')
        // 获取子组件实例中的数据
        console.log(' getChildComponent', child, child.data.keyword)

        // 调用子组件的方法
        child.print()
    }
})