
Component({

    // 声明接收父组件传递的数据属性
    properties: {
        // 方式1：key属性名，value数据类型：Number/String/Boolean/Object/Array/ null 代表不限制类型
        _id: Number, // 默认值是0
        // 方式2： key属性名，value是对象{type 指定数据类型，value指定默认值，optionalTypes指定多个数据类型}
        name: {
            type: String,// 数据类型
            value: 'mxg' // 默认值，父组件未传递时取此值
        },
        isPublished: Boolean, // 默认值是false
        commentIds: { // 支持String/Number/Array类型
            type: String,
            optionalTypes: [Number, Array],
            value: [0] // 默认值是数组 [0]
        },
        course: Object
    },

    data: {
        keyword: ''
    },

    
    // 组件中声明自定义方法,需要放到methods选项中
    methods: {
        print() {
            const {_id, name, isPublished} = this.properties
            console.log('print', _id, name, isPublished, this.properties.commentIds)
            // 不要子组件修改properties的属性值, 可能导致未知错误,如果需要修改,则通过自定义事件方式
            //this.properties.name = "mengxuegu"
            /* this.setData({
                name: 'mengxuegu'
            }) */
            
        },
        // 搜索
        search() {
            console.log('子组件search', this.data.keyword)
            // 触发父组件绑定的自定义事件,向它传递数据
            const data = {keyword: this.data.keyword, name: 'mengxuegu'}
            this.triggerEvent('searchGoods', data )
        }
    }

})