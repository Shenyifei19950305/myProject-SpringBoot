const formatTime = date => {
  const year = date.getFullYear()
  const month = date.getMonth() + 1
  const day = date.getDate()
  const hour = date.getHours()
  const minute = date.getMinutes()
  const second = date.getSeconds()

  return `${[year, month, day].map(formatNumber).join('/')} ${[hour, minute, second].map(formatNumber).join(':')}`
}

const formatNumber = n => {
  n = n.toString()
  return n[1] ? n : `0${n}`
}

// 将 rpx转换px
function rpx2px(rpx) {
   const { windowWidth } = wx.getWindowInfo()
   // 转换后的px值= 手机屏幕宽度 * 小程序基准宽度750rpx * 要转换的rpx值
   return windowWidth / 750 * rpx
}

// es5
/* module.exports = {
  formatTime: formatTime
} */

// es6导出默认对象
export default {
    formatTime: formatTime,
    rpx2px, // rpx2px: rpx2px
}

