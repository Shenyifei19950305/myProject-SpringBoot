Page({
    data: {
        color: 'blue'
    }
})