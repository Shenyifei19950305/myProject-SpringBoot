// var util = require('../../utils/util.js')
// 使用别名 @/ 表示项目根目录 ，
/* var util = require('@/utils/util.js')
util.formatTime(new Date()) */

// es6 导入模块
import util from '@/utils/util'
let date = util.formatTime(new Date())
date = new Date()

Page({
    data: {
        name: '张三'
    },

    onLoad() {
        // const 定义的常量 ，后面不允许修改
        const i = 1
        //i = 10 //  "i" is read-only

       /*  wx.navigateTo({
            url: 'pages/course/course',
            fail: (error) => {
                console.log('跳转页面失败', error) // navigateTo:fail page "pages/index/pages/course/course" is not found
            }
        }) */

        // 获取全局变量，通过 getApp() 方法先获取app实例
        const app = getApp()
        // 全局变量 我是全局数据 张三
        console.log('全局变量', app.globalData, app.firstname)
        //app.firstname = '小刘'  // 修改全局变量值
        app.age = 18 // 向全局中新增一个age变量
        console.log('age', app.age)

        app.globalMethod() // globalMethod
        app.login() // login
    }
})