// var util = require('../../utils/util.js')
// 使用别名 @/ 表示项目根目录 ，
/* var util = require('@/utils/util.js')
util.formatTime(new Date()) */

// es6 导入模块
import util from '@/utils/util'
let date = util.formatTime(new Date())
date = new Date()
// rpx转px 320
console.log('rpx转px', util.rpx2px(30))

Page({
    data: {
        name: '张三'
    },

    onLoad() {
        // const 定义的常量 ，后面不允许修改
        const i = 1
        //i = 10 //  "i" is read-only

       /*  wx.navigateTo({
            url: 'pages/course/course',
            fail: (error) => {
                console.log('跳转页面失败', error) // navigateTo:fail page "pages/index/pages/course/course" is not found
            }
        }) */

        // 获取全局变量，通过 getApp() 方法先获取app实例
        const app = getApp()
        // 全局变量 我是全局数据 张三
        console.log('全局变量', app.globalData, app.firstname)
        //app.firstname = '小刘'  // 修改全局变量值
        app.age = 18 // 向全局中新增一个age变量
        console.log('age', app.age)

        app.globalMethod() // globalMethod
        app.login() // login

    },


    // ----- 路由Api ---
    toRoutePage() {
       // 跳转到应用内的某个页面，不支持跳转tabBar页面
       /* wx.navigateTo({
         url: '/pages/shopping/shopping',
         fail(error) {
             console.log('fail', error)
         }
       }) */

       wx.navigateTo({
           url: '/pages/route/route?paramA=111&paramB=222', // 目标页面地址, 以/开头
           events: {// 定义监听器，来获取被打开页面传递的数据
                acceptData(data) {
                    console.log('接收被打开页面传递的数据', data)
                }
           },
           success(res) {
               console.log('跳转成功')
               // 通过eventChannel对象向打开的页面传递数据
               res.eventChannel.emit('userInfoEvent', {username: 'mengxuegu'})
           },
           fail(error) {
               console.log('跳转失败', error)
           },
           complete() {
               console.log("不管成功还是失败都会调用")
           }
       })

       
    },

    toTabBarPage() {
        // wx.switchTab 跳转到 tabBar 页面，不能跳转到普通页面,
        // 并且路径后面不能带参数
        wx.switchTab({
            url: '/pages/shopping/shopping',
            // url: '/pages/shopping/shopping?paramA=111', // 不支持路径参数
            // url: '/pages/route/route', // 不能跳转到普通页面
        })

        // 向tabBar中传递参数, 要使用全局变量 App
        const app = getApp()
        app.goodsInfo = {goodsName: '微信小程序教程'}
    },

    // toPageByRedirectTo() {
    //     wx.redirectTo({
    //       url: '/pages/route/route',
    //     })
    // }

})