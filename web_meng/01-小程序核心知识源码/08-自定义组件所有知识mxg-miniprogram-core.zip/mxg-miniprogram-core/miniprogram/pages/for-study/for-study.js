
Page({
    data: {
        array: [1, 2, 3, 4, 5],
        orderList: [
            {id: 1, shopName: '梦家1店', orderAmount: 1000, orderNum: 2},
            {id: 2, shopName: '梦学谷', orderAmount: 2000, orderNum: 1},
        ],
        dept: {
            deptId: 1,
            deptName: '技术部'
        }
    }
})