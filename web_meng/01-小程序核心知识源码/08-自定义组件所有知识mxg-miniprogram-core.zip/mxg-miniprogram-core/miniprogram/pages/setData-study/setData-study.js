
Page({
    data: {
        num: 1,
        user: {
            id: 1,
            nickname: '桃姐'
        },
        array: [
            {id: 1, name: '白白'},
            {id: 2, name: '默默'}
        ]
    },

    // 更新 data 中的 num 值
    updateNum() {
        // this.data.xxxx 来获取 data 中定义的状态属性
        /* const num = this.data.num
        console.log('updateNum', num) */

        // 直接赋值：只会修改data的属性值，不会更新视图的数据
        /* this.data.num = this.data.num+1  // this.data.num += 1  
        console.log('num', this.data.num) // num 2 */

        /**
         * 通过 this.setData 来更新data选项中的属性值（同步），且更新页面的数据(异步)
         * 参数1（必填）：是接收一个对象，key是data选项中的属性名，value是要更新的值
         * 参数2（非必填）：页面更新渲染完成后的回调函数
         * 
         * this.setData({num: this.data.num+1})
         */
        /* this.setData({num: this.data.num+1}, () => {
            // 当页面更新完成后，会回调此函数
            console.log('更新页面数据num已完成')
        })
        console.log('setData更新后的num值', this.data.num) */

        // 如果更新后的值是undefined，视图并不会更新为undefined, 这样会导致一些业务错误
        const newNum = undefined || 0
        this.setData({num: newNum}) 
        console.log('传递undefined后的num值是', this.data.num) // undefined
    },

    // 更新对象数据
    updateUser() {
        /* this.setData({
            // 修改对象属性，key直接指定数据路径 a.b.c.d.xxx
            'user.nickname': '小梦', // 修改this.data.user.nickname属性值
            'user.age': 18 // 新增一个 user.age属性，值为18
        }) */

        // console.log('data', this.data)

        // 如果要修改的数据比较多，则可先解析出原来的数据对象，再进行修改、新增属性
        /* const { user } = this.data
        user.nickname = '飞哥' // 修改原有的属性值
        user.age = 30 // 新增的属性
        this.setData({ 
           user // 等价于 user: user
        }) */

        // 全部替换为一个新数据
        const newUser = {id: 2, nickname: '小白', salary: 20000}
        this.setData({user: newUser})
    },

    // 更新数组数据
    updateArray() {
        // 更新数组中元素的数据，通过数据路径进行更新
        /* this.setData({
            'array[0].name': '小刘' // 修改array数组中下标为0的name属性值为 小刘
        }) */

        // 追加一个元素到array中
        /* const {array} = this.data 
        // 取出原数组，然后通过push追加元素
        array.push({id: 3, name: '小梦'}) 
        // 将更新后的数组重新的进行数据和视图更新  
        this.setData({array: array}) */

        // 删除数组中下标为0的元素（第1个元素）
        /* const { array } = this.data
        array.shift(0, 1) // 删除下标为0的元素，删除1个
        this.setData({ array: array }) */

        // 追加一个新的数组到原数组后面
        const newArray = [{id: 3, name: '小红'}, {id: 4, name: '小绿'}]
        const {array} = this.data
        // 将 newArray 数组追加到 array 后面，并返回一个新的数组
        const targetArray = array.concat(newArray)
        // console.log('targetArray', targetArray)
        this.setData({ array: targetArray })
    }
})