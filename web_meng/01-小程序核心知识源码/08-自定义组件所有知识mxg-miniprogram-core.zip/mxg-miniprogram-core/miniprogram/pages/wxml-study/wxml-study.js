
Page({
    // 定义状态数据
    data: { 
        name: '小梦',
        salary: 10000, // 工资
        bonus: 500, // 奖金
        sex: 3, // 1-男，2女
        dept: {
            deptId: 1,
            deptName: '研发部'
        },
        likes: ['打码', '篮球', '美女'],

        color: 'red',
        bgColor: '#000',
        id: 1,


        inputValue: '我是输入框的值1',

    },

    test(data) {
        console.log('test')
        return 111
    },
    
    // 测试接收的数值
    handleBindNum(event) {
        // {age: "18", sex: "1"}
        //  {age: 18, sex: "1", state: "true"}
        // {age: 18, sex: "1", state: true}
        console.log('handleBindNum', event, event.currentTarget.dataset.age + 111)
    }
})