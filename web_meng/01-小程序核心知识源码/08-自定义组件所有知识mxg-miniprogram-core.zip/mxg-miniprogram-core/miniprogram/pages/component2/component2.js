
// 
/* 
使用 Component 构造页面逻辑
1. 页面.json中添加 usingComponents
{
  "usingComponents": {}
}
2. 使用Component构造时，配置项需要与组件配置项一致
    比如：自定义方法要写到 methods 选项中
3. properties 用于接收其他页面跳转到此页面时所带的路径参数
4. ⼩程序框架提供的以on开头的：⻚⾯⽣命周期函数、事件监听函数，放在 methods 选项中
    比如： ⻚⾯⽣命周期函数 onLoad、onRead、onShow、onHide ……
    事件监听函数：onPullDownRefresh、onReachBottom、onShareAppMessage ……
*/

Component({

    // properties 用于接收其他页面跳转到此页面时所带的路径参数
    // wx.navigateTo({url: '/pages/component2/component2?paramA=123&paramB=aaa'})
    // 接收后，直接通过this.data.paramA可访问到
    properties: {
        paramA: Number,
        paramB: String
    },

    data: {
        msg: '此页面是通过Component构建的'
    },

    methods: {
        // ⼩程序框架提供的以on开头的：⻚⾯⽣命周期函数、事件监听函数，放在 methods 选项中
        onLoad() {
            console.log('获取路径参数', this.data.paramA, this.data.paramB)
            this.print()
        },

        // 自定义函数也要放到 methods 选项中
        print() {
            console.log("print")
        }
    },

    observers: {
        // 定义监听器
    }
})