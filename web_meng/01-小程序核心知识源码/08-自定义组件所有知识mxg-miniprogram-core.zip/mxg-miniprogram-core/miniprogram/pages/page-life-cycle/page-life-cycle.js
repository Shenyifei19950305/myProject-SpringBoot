// pages/page-life-cycle/page-life-cycle.js

/**
 *  onLoad 页面加载时触发 {}
    onShow 页面显示时触发
    onReady 页面初次渲染完成触发
 * 
 */
Page({
    data: {
        id: '',
        name: '',
    },

    // /pages/page-life-cycle/page-life-cycle?id=1&name=mxg
    // 会将路径参数，转换为对象传递到onLoad参数中 options: {id: "1", name: "mxg"}
    // 只在页面初次加载时调用1 次
    onLoad(options) { 
        // 做一些初始化的操作，比如：从本地中获取数据，然后将数据初始化给data选项中的属性
        console.log('onLoad 页面加载时触发', options) 
        this.setData({
            id: options.id,
            name: options.name
        })
    },

    // 调用 1+n 次，
    onShow() {
        console.log('onShow 页面显示时触发')
    },
    
    // 页面初次渲染完成 时调用1次
    onReady() {
        console.log('onReady 页面初次渲染完成触发')
    },

    // 调用 n 次，wx.navigateTo 跳转到一个页面，隐藏当前页面时会调用
    onHide() {
        console.log('onHide 页面隐藏时触发')
    },
    
    // 调用1次，比如：页面后退
    onUnload() {
        // 一般做一些释放资源的事情
        console.log('onUnload 页面卸载/销毁时触发')
    },
    
})