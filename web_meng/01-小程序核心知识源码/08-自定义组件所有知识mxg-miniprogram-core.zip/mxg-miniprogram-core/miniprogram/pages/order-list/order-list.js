
Page({
    data: {
        htmlContent: "<div style='color: red;'>我是html格式数据</div>"
    }
})