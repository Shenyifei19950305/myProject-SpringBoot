
Page({
    // 定义状态数据
    data: {

    },

    // 定义自定义函数/方法
    handleConfirm(event) {
        /* const username = event.currentTarget.dataset.username
        const totalNum = event.currentTarget.dataset.totalNum */
        const {username, totalNum} = event.currentTarget.dataset
        console.log('handleConfirm', event, username, totalNum)
    },

    // 子按钮点击事件的处理函数
    handleChild(event) {
        console.log('handleChild', event)
    },

    // 父view点击事件的处理函数
    handleParent(event) {
        console.log('handleParent', event)
    },

    // 点击【确定1】按钮
    handleConfirm1(e) {
        const sex = e.mark.sex
        console.log('handleConfirm1', e, sex)
    }



})