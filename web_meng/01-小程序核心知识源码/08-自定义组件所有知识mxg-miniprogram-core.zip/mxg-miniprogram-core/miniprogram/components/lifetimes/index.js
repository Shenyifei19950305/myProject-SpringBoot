
Component({

    /**
     * 定义生命周期函数：
     * 方式1：直接在Component构造器的第一级参数中定义
     * 方式2：(推荐）通过 lifetimes 选项进行定义
     */
    // 方式1：直接在Component构造器的第一级参数中定义
    /* created() {
    },
    attached() {
    },
    detached() {
    }, */

    data: {
        msg: 'hello，组件生命周期'
    },

    // 方式2：(推荐）通过 lifetimes 选项进行定义组件生命周期函数
    lifetimes: {

        // 在组件实例刚刚被创建时执行，注意此时不能调用 setData
        created() { 
            console.log('created--组件实例已创建')
            // 不能使用 this.setData修改属性数据，3.5.5开始支持修改（但是不建议使用）
            /* this.setData({
                msg: 'create中更新了msg值'
            }) */

            // 一般用于向this中添加属性
            this.isOpen = true
        },

        // 一般用于data属性数据初始化操作
        attached() {
            console.log('attached--组件模板已初始，但未渲染出来')

            // console.log('访问this中自定义属性', this.isOpen)
            // 查询后端的数据，查询到了数据后更新属性值
            this.setData({
                msg: 'attached更新了msg的值'
            })
        },

        ready() {
            console.log('ready--页面已被初始渲染')
        },

        detached() { 
            // 一般用于释放资源
            console.log("detached--页面已销毁")
        }

    },

    // 定义 组件所在页面的生命周期函数
    pageLifetimes: {
        show() {
            console.log('pageLifetimes.show--当前组件所在页面被显示 ')
        },
        hide() {
            console.log('pageLifetimes.hide--当前组件所在页面被隐藏')
        },
        resize(obj) {
            // 在页面 component.json 中配置 "pageOrientation": "auto" 开启屏幕可旋转
            console.log('pageLifetimes.resize--当前组件所在页面大小已改变', obj)
        }
    }




})