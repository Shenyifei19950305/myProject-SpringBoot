
Component({
    options: {
        // 开启多个slot插槽出口, 如果不开启: wxml中只能一个slot(默认插槽)
        multipleSlots: true
    }
})