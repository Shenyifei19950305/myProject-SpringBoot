// components/banner/index.js
Component({
  options: {
      // 默认情况下样式是隔离的，自定义组件无法引用到全局样式，添加下面的可以解决，
    addGlobalClass: true
  },

  /* 定义子组件接收父组件传递的数据属性（数据字段） */
  properties: {
      // key 就是属性名，value是属性的数据类型：Array/Number/String/Object/Boolean, null表示不限制类型
    bannerList: Array
  },

  data: {

  },

  // 在methods中声明自定义函数
  methods: {
    handle() {
        // 触发父组件绑定的自定义事件，向父组件传递数据
        // 参数1：触发的自定义事件名，参数2：传递的数据
        this.triggerEvent('navTo', 1111)
    }
  }

})