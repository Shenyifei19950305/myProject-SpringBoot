
// 1、导入Behavior
import myBeahavior from '@/behaviors/my-behavior.js'

Component({

    // 引用Behavior
    behaviors: [myBeahavior ],

    options: {
        // addGlobalClass: true
        /* 
            styleIsolation 配置样式的隔离级别：
            - isolated （默认值）：表示 启用样式隔离，组件样式内外都不会相互影响
            - apply-shared:（一般要用到全局样式式设置此值） 表示父组件样式将影响当前子组件样式，子组件样式不会影响父组件样式
            - shared: (一般不用) 父子组件样式会相互作用（相互影响），并且会样式会作用到设置了 shared和 apply-shared 的自定义组件中
        */
        //    styleIsolation: 'apply-shared' // 等价于 addGlobalClass: true
        styleIsolation: 'shared'
    },

    // 声明接收父组件传递的数据属性
    properties: {
        // 方式1：key属性名，value数据类型：Number/String/Boolean/Object/Array/ null 代表不限制类型
        _id: Number, // 默认值是0
        // 方式2： key属性名，value是对象{type 指定数据类型，value指定默认值，optionalTypes指定多个数据类型}
        name: {
            type: String,// 数据类型
            value: 'mxg' // 默认值，父组件未传递时取此值
        },
        isPublished: Boolean, // 默认值是false
        commentIds: { // 支持String/Number/Array类型
            type: String,
            optionalTypes: [Number, Array],
            value: [0] // 默认值是数组 [0]
        },
        course: Object
    },

    // 组件生命周期函数，加载组件时调用
    attached() {
        console.log('child-component.attached', this.data)
        // 调用外部Behavior中定义的方法
        this.myBehaviorMethod()
    },


    data: {
        keyword: '',
        result: '',
        numberA: 0,
        numberB: 0,
        sum: 0,
        query: {
            username: '',
            age: 18
        },
        array: [1, 2],
    },

    
    // 组件中声明自定义方法,需要放到methods选项中
    methods: {

        print() {
            const {_id, name, isPublished} = this.properties
            console.log('print', _id, name, isPublished, this.properties.commentIds)
            // 不要子组件修改properties的属性值, 可能导致未知错误,如果需要修改,则通过自定义事件方式
            //this.properties.name = "mengxuegu"
            /* this.setData({
                name: 'mengxuegu'
            }) */
            
        },
        // 搜索
        search() {
            console.log('子组件search', this.data.keyword)
            // 触发父组件绑定的自定义事件,向它传递数据
            const data = {keyword: this.data.keyword, name: 'mengxuegu'}
            this.triggerEvent('searchGoods', data )
        },

        updateData() {
            console.log('updateData')
            // 通过直接赋值方式不会触发监听器
            /* this.data.numberA = 10
            this.data.numberB = 20 */

            // 调用一次setData就会触发到对应属性的监听器
            /* this.setData({
                numberA: 10,
                numberB: 20
            }) */

            this.setData({
                'query.username': '涛姐',
                'query.age': 20,
                'array[0]': 2
            })
        }
    },

    // observers 定义监听器, 监听数据的响应式变化
    observers: {
        // 监听keyword数据的model变化 ,
        // key: 监听的属性名, value是一个回调函数: 当属性值改变后,会带上最新的数据传递到此回调此函数中, 注意:回调函数不要写箭头函数, 不然this就是undefine
        // keyword: (newVal) => { // 错误的写法,注意:回调函数不要写箭头函数, 不然this就是undefine
        // keyword: function (newVal) {  } 
        keyword(newVal) { // 函数名是要监听的属性, 
            console.log('监听到keyword变化', newVal, this)
            if (newVal.includes('meng')) {
                this.setData({result: 'hello, mengxuegu'})
            } else {
                this.setData({result: '未搜索到数据'})
            }
        },

        // 同时监听多个属性的变化, 使用英文逗号进行多个属性的分隔
        // numberA 或者 numberB 属性值改变后,变会调用此函数
        'numberA, numberB' (numberA, numberB) {
            console.log('监听数字的变化', numberA, numberB)
            this.setData({
                sum: numberA + numberB,
                //numberA: 210 // 不要在监听器回调函数体中将自身属性值更新,不然会出现死循环
            })
        },

        // 监听对象属性，使用属性路径方式指定
        // 监听 query对象中的username属性值变化 
        'query.username' (username) {
            console.log("监听到query.username变化", username)
        },
        // 监听对象中所有子属性的变化，可以使用通配符 **
        'query.**' (query) {
            console.log('监听到query对象的变化', query)
        },

        // 监听数组中某个元素的改变 
        'array[0]' (newVal) {
            console.log('监听到数组中下标为0的元素变化', newVal)
        }
    }

})