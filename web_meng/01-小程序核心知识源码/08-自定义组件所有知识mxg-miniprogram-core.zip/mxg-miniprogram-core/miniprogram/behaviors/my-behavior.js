
// 引用者会覆盖被引用的Behavior中的Properties和methods中的同名属性和方法
// import OtherBehavior from './other-behavior.js'

// 注册一个Behavior，接收一个Object类型的参数
export default Behavior({
    // 引用其他的behavior
    behaviors: [ ],

    // 定义接收父组件的传递的数据属性
    properties: {
        myBehaviorProperty: {
            type: String,
            value: '我是Behavior的Prop'
        }, 
        name: {
            type: String,
            value: '我是Behavior的Prop---name'
        }
    },

    // 定义当前组件的数据属性
    data: {
        myBehaviorData: {
            name: '我是Behavior的Data'
        },
        query: {
            nickname: '我是Behavior的query.nickname'
        },
        sum: 10
    },

    // 自定义方法声明
    methods: {
        myBehaviorMethod() {
            console.log('我是Behavior方法')
        }
    },

    attached() {
        console.log('my-behavior.js中的attached组件生命周期函数')
    },

    observers: {
    }
    // 其他的Component中的选项

})