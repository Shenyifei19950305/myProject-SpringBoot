// app.js
App({
    // 打开小程序 》隐藏小程序》显示小程序
    onLaunch() { // 只访问1次
        console.log('应用生命周期-onLaunch, 小程序初始化操作')
    },

    onShow() { // 被访问1+n次
        console.log('应用生命周期-onShow, 小程序启动，或者从后台进入前台显示时触发 ')
    },
    
    onHide() { // 被访问1+n次
        console.log('应用生命周期-onHide, 小程序从前台进入后台隐藏时触发')
    },

    onError(error) {
        //console.log('onError-小程序出现脚本错误或者api调用时出错', error)
    },

    // 意义不大，页面跳转找不到时不会触发这个函数，因为跳转的方法可以会自行处理
    onPageNotFound() {
        console.log('onPageNotFound')
    },

    // 全局变量
    globalData: '我是全局数据',
    firstname: '张三',

    // 全局方法
    globalMethod() {
        console.log('globalMethod')
    },

    // 全局方法
    login() {
        console.log('login')
    }

})
