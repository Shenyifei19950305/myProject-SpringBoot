// var util = require('../../utils/util.js')
// 使用别名 @/ 表示项目根目录 ，
var util = require('@/utils/util.js')
util.formatTime(new Date())
